﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.additionRb = New System.Windows.Forms.RadioButton()
        Me.subtractRb = New System.Windows.Forms.RadioButton()
        Me.multiplyRb = New System.Windows.Forms.RadioButton()
        Me.divideRb = New System.Windows.Forms.RadioButton()
        Me.input1TextBox = New System.Windows.Forms.TextBox()
        Me.input2TextBox = New System.Windows.Forms.TextBox()
        Me.calculateBtn = New System.Windows.Forms.Button()
        Me.clearBtn = New System.Windows.Forms.Button()
        Me.answerLbl = New System.Windows.Forms.Label()
        Me.symbolLbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'additionRb
        '
        Me.additionRb.AutoSize = True
        Me.additionRb.Location = New System.Drawing.Point(12, 12)
        Me.additionRb.Name = "additionRb"
        Me.additionRb.Size = New System.Drawing.Size(44, 17)
        Me.additionRb.TabIndex = 0
        Me.additionRb.Text = "Add"
        Me.additionRb.UseVisualStyleBackColor = True
        '
        'subtractRb
        '
        Me.subtractRb.AutoSize = True
        Me.subtractRb.Location = New System.Drawing.Point(12, 35)
        Me.subtractRb.Name = "subtractRb"
        Me.subtractRb.Size = New System.Drawing.Size(65, 17)
        Me.subtractRb.TabIndex = 1
        Me.subtractRb.Text = "Subtract"
        Me.subtractRb.UseVisualStyleBackColor = True
        '
        'multiplyRb
        '
        Me.multiplyRb.AutoSize = True
        Me.multiplyRb.Location = New System.Drawing.Point(12, 58)
        Me.multiplyRb.Name = "multiplyRb"
        Me.multiplyRb.Size = New System.Drawing.Size(60, 17)
        Me.multiplyRb.TabIndex = 2
        Me.multiplyRb.Text = "Multiply"
        Me.multiplyRb.UseVisualStyleBackColor = True
        '
        'divideRb
        '
        Me.divideRb.AutoSize = True
        Me.divideRb.Location = New System.Drawing.Point(12, 81)
        Me.divideRb.Name = "divideRb"
        Me.divideRb.Size = New System.Drawing.Size(55, 17)
        Me.divideRb.TabIndex = 3
        Me.divideRb.Text = "Divide"
        Me.divideRb.UseVisualStyleBackColor = True
        '
        'input1TextBox
        '
        Me.input1TextBox.Location = New System.Drawing.Point(12, 160)
        Me.input1TextBox.Name = "input1TextBox"
        Me.input1TextBox.Size = New System.Drawing.Size(100, 20)
        Me.input1TextBox.TabIndex = 4
        '
        'input2TextBox
        '
        Me.input2TextBox.Location = New System.Drawing.Point(172, 160)
        Me.input2TextBox.Name = "input2TextBox"
        Me.input2TextBox.Size = New System.Drawing.Size(100, 20)
        Me.input2TextBox.TabIndex = 5
        '
        'calculateBtn
        '
        Me.calculateBtn.Location = New System.Drawing.Point(13, 198)
        Me.calculateBtn.Name = "calculateBtn"
        Me.calculateBtn.Size = New System.Drawing.Size(75, 23)
        Me.calculateBtn.TabIndex = 6
        Me.calculateBtn.Text = "Calculate"
        Me.calculateBtn.UseVisualStyleBackColor = True
        '
        'clearBtn
        '
        Me.clearBtn.Location = New System.Drawing.Point(13, 227)
        Me.clearBtn.Name = "clearBtn"
        Me.clearBtn.Size = New System.Drawing.Size(75, 23)
        Me.clearBtn.TabIndex = 7
        Me.clearBtn.Text = "Clear"
        Me.clearBtn.UseVisualStyleBackColor = True
        '
        'answerLbl
        '
        Me.answerLbl.AutoSize = True
        Me.answerLbl.Location = New System.Drawing.Point(169, 208)
        Me.answerLbl.Name = "answerLbl"
        Me.answerLbl.Size = New System.Drawing.Size(0, 13)
        Me.answerLbl.TabIndex = 8
        '
        'symbolLbl
        '
        Me.symbolLbl.AutoSize = True
        Me.symbolLbl.Location = New System.Drawing.Point(138, 167)
        Me.symbolLbl.Name = "symbolLbl"
        Me.symbolLbl.Size = New System.Drawing.Size(0, 13)
        Me.symbolLbl.TabIndex = 9
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(341, 262)
        Me.Controls.Add(Me.symbolLbl)
        Me.Controls.Add(Me.answerLbl)
        Me.Controls.Add(Me.clearBtn)
        Me.Controls.Add(Me.calculateBtn)
        Me.Controls.Add(Me.input2TextBox)
        Me.Controls.Add(Me.input1TextBox)
        Me.Controls.Add(Me.divideRb)
        Me.Controls.Add(Me.multiplyRb)
        Me.Controls.Add(Me.subtractRb)
        Me.Controls.Add(Me.additionRb)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents additionRb As System.Windows.Forms.RadioButton
    Friend WithEvents subtractRb As System.Windows.Forms.RadioButton
    Friend WithEvents multiplyRb As System.Windows.Forms.RadioButton
    Friend WithEvents divideRb As System.Windows.Forms.RadioButton
    Friend WithEvents input1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents input2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents calculateBtn As System.Windows.Forms.Button
    Friend WithEvents clearBtn As System.Windows.Forms.Button
    Friend WithEvents answerLbl As System.Windows.Forms.Label
    Friend WithEvents symbolLbl As System.Windows.Forms.Label

End Class
