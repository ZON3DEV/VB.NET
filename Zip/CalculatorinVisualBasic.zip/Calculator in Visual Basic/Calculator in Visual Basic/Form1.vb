﻿'This tutorial is provided in part by Server Intellect Web Hosting Solutions _http://www.serverintellect.com
' Visit _http://v4.vbasic.net for more v4.vbasic.net Tutorials

Public Class Form1

    Private Sub calculateBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles calculateBtn.Click
        Dim number1 As Double
        Dim number2 As Double
        Dim answer As Double

        If input1TextBox.Text = "" OrElse input2TextBox.Text = "" Then
            MessageBox.Show("Please Enter a Number")
        ElseIf additionRb.Checked = False And subtractRb.Checked = False And multiplyRb.Checked = False And divideRb.Checked = False Then
            MessageBox.Show("Please Choose an Operation")
        Else
            number1 = Double.Parse(input1TextBox.Text)
            number2 = Double.Parse(input2TextBox.Text)

            If additionRb.Checked = True Then
                answer = number1 + number2
                answerLbl.Text = answer.ToString()
            ElseIf subtractRb.Checked = True Then
                answer = number1 - number2
                answerLbl.Text = answer.ToString()
            ElseIf multiplyRb.Checked = True Then
                If number1 = 0 OrElse number2 = 0 Then
                    answerLbl.Text = "0"
                Else
                    answer = number1 * number2
                    answerLbl.Text = answer.ToString()
                End If
            ElseIf divideRb.Checked = True Then
                If number1 = 0 Then
                    answerLbl.Text = "0"
                ElseIf number2 = 0 Then
                    answerLbl.Text = "Cannot Divide by Zero"
                Else
                    answer = number1 / number2
                    answerLbl.Text = answer.ToString()
                End If
            End If
        End If

    End Sub

    Private Sub additionRb_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles additionRb.CheckedChanged
        symbolLbl.Text = "+"
        answerLbl.Text = ""
    End Sub

    Private Sub subtractRb_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles subtractRb.CheckedChanged
        symbolLbl.Text = "-"
        answerLbl.Text = ""
    End Sub

    Private Sub multiplyRb_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles multiplyRb.CheckedChanged
        symbolLbl.Text = "*"
        answerLbl.Text = ""
    End Sub

    Private Sub divideRb_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles divideRb.CheckedChanged
        symbolLbl.Text = "/"
        answerLbl.Text = ""
    End Sub

    Private Sub clearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearBtn.Click
        input1TextBox.Text = ""
        input2TextBox.Text = ""
        answerLbl.Text = ""

        If additionRb.Checked = True Then
            additionRb.Checked = False
            symbolLbl.Text = ""
        ElseIf subtractRb.Checked = True Then
            subtractRb.Checked = False
            symbolLbl.Text = ""
        ElseIf multiplyRb.Checked = True Then
            multiplyRb.Checked = False
            symbolLbl.Text = ""
        Else
            divideRb.Checked = False
            symbolLbl.Text = ""
        End If
    End Sub

End Class
