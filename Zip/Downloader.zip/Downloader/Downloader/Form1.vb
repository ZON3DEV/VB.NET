﻿Imports System.Net
Public Class Form1
    Public WithEvents download As WebClient

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            download = New WebClient
            download.DownloadFileAsync(New Uri(TextBox1.Text), TextBox2.Text)
        Catch ex As Exception
            MsgBox("Fehler! -" & ex.Message)
        End Try
    End Sub
    Private Sub download_DownloadProgressChanged(ByVal sender As System.Object, ByVal e As System.Net.DownloadProgressChangedEventArgs) Handles download.DownloadProgressChanged
        Try
            Label1.Text = "Downloaded: " & e.BytesReceived / 1000000 & "  MB / " & e.TotalBytesToReceive / 1000000 & " MB"
            ProgressBar1.Value = e.ProgressPercentage
            Label2.Text = ProgressBar1.Value & "%"
        Catch ex As Exception

        End Try


    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Dim ofd As New SaveFileDialog
        ofd.Filter = "All Files (*.*)|*.*"
        ofd.ShowDialog()
        TextBox2.Text = ofd.FileName
    End Sub
End Class
