﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.VLCPnl = New System.Windows.Forms.Panel()
        Me.AxVLCPlugin21 = New AxAXVLC.AxVLCPlugin2()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.PlayBtn = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.PauseBtn = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ComedyList = New System.Windows.Forms.ComboBox()
        Me.ArniList = New System.Windows.Forms.ComboBox()
        Me.FantasyList = New System.Windows.Forms.ComboBox()
        Me.ActionList = New System.Windows.Forms.ComboBox()
        Me.WesternList = New System.Windows.Forms.ComboBox()
        Me.AdrianoList = New System.Windows.Forms.ComboBox()
        Me.SciFiList = New System.Windows.Forms.ComboBox()
        Me.KlassikList = New System.Windows.Forms.ComboBox()
        Me.LouisList = New System.Windows.Forms.ComboBox()
        Me.HorrorList = New System.Windows.Forms.ComboBox()
        Me.StaloneList = New System.Windows.Forms.ComboBox()
        Me.JCVDList = New System.Windows.Forms.ComboBox()
        Me.ActionListPlayBtn = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.WMPPnl = New System.Windows.Forms.Panel()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.PlayerBtn1 = New System.Windows.Forms.Button()
        Me.PlayerBtn2 = New System.Windows.Forms.Button()
        Me.PlayerPic1 = New System.Windows.Forms.PictureBox()
        Me.PlayerPic2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.SciFiBtn = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.PosOnBtn = New System.Windows.Forms.Button()
        Me.VolOnBtn = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.InfoOnBtn = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.VolOffBtn = New System.Windows.Forms.Button()
        Me.PosOffBtn = New System.Windows.Forms.Button()
        Me.MenuOff = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.InfoOffBtn = New System.Windows.Forms.Button()
        Me.TimerResetBtn = New System.Windows.Forms.Button()
        Me.TimerStopBtn = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.KlassikBtn = New System.Windows.Forms.Button()
        Me.LouisBtn = New System.Windows.Forms.Button()
        Me.AdrianoBtn = New System.Windows.Forms.Button()
        Me.ArniBtn = New System.Windows.Forms.Button()
        Me.StaloneBtn = New System.Windows.Forms.Button()
        Me.ExtraOnBtn = New System.Windows.Forms.Button()
        Me.ExtraOffBtn = New System.Windows.Forms.Button()
        Me.UpdateBtn = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.WesternPic2 = New System.Windows.Forms.PictureBox()
        Me.WesternPic1 = New System.Windows.Forms.PictureBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.FantasyPic2 = New System.Windows.Forms.PictureBox()
        Me.FantasyPic1 = New System.Windows.Forms.PictureBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ActionPic2 = New System.Windows.Forms.PictureBox()
        Me.ComedyPic2 = New System.Windows.Forms.PictureBox()
        Me.HorrorPic2 = New System.Windows.Forms.PictureBox()
        Me.HorrorPic1 = New System.Windows.Forms.PictureBox()
        Me.SciFiPic2 = New System.Windows.Forms.PictureBox()
        Me.ComedyPic1 = New System.Windows.Forms.PictureBox()
        Me.ActionPic1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SciFiPic1 = New System.Windows.Forms.PictureBox()
        Me.ActionPnl = New System.Windows.Forms.Panel()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.HorrorListPlayBtn = New System.Windows.Forms.Button()
        Me.FantasyListPlayBtn = New System.Windows.Forms.Button()
        Me.SciFiListPlayBtn = New System.Windows.Forms.Button()
        Me.ComedyListPlayBtn = New System.Windows.Forms.Button()
        Me.MenuOn = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.VolPnl = New System.Windows.Forms.Panel()
        Me.TrackBar2 = New System.Windows.Forms.TrackBar()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.BufferBarOff = New System.Windows.Forms.ProgressBar()
        Me.BufferBarOn = New System.Windows.Forms.ProgressBar()
        Me.MenuPnlHider = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.InfoPnl = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.IMDBlbl = New System.Windows.Forms.Label()
        Me.Yearlbl = New System.Windows.Forms.Label()
        Me.Genrelbl = New System.Windows.Forms.Label()
        Me.Durationlbl = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Milliseklbl = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Seklbl = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Minlbl = New System.Windows.Forms.Label()
        Me.Min = New System.Windows.Forms.Timer(Me.components)
        Me.Sek = New System.Windows.Forms.Timer(Me.components)
        Me.Millisek = New System.Windows.Forms.Timer(Me.components)
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Filenamelbl = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.BarBtn1 = New System.Windows.Forms.Button()
        Me.BarBtn2 = New System.Windows.Forms.Button()
        Me.ExtraPnl = New System.Windows.Forms.Panel()
        Me.KlassikPic2 = New System.Windows.Forms.PictureBox()
        Me.KlassikPic1 = New System.Windows.Forms.PictureBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.LouisPic2 = New System.Windows.Forms.PictureBox()
        Me.LouisPic1 = New System.Windows.Forms.PictureBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.JCVDPic2 = New System.Windows.Forms.PictureBox()
        Me.StalonePic2 = New System.Windows.Forms.PictureBox()
        Me.AdrianoPic2 = New System.Windows.Forms.PictureBox()
        Me.AdrianoPic1 = New System.Windows.Forms.PictureBox()
        Me.ArniPic2 = New System.Windows.Forms.PictureBox()
        Me.StalonePic1 = New System.Windows.Forms.PictureBox()
        Me.JCVDPic1 = New System.Windows.Forms.PictureBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.JCVDBtn = New System.Windows.Forms.Button()
        Me.ArniPic1 = New System.Windows.Forms.PictureBox()
        Me.VLCPnl.SuspendLayout()
        CType(Me.AxVLCPlugin21, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.WMPPnl.SuspendLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PlayerPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PlayerPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.WesternPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WesternPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FantasyPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FantasyPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ActionPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComedyPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HorrorPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HorrorPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SciFiPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComedyPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ActionPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SciFiPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ActionPnl.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.VolPnl.SuspendLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuPnlHider.SuspendLayout()
        Me.Panel11.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.InfoPnl.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.ExtraPnl.SuspendLayout()
        CType(Me.KlassikPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KlassikPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LouisPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LouisPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.JCVDPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StalonePic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdrianoPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdrianoPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ArniPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StalonePic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.JCVDPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ArniPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VLCPnl
        '
        Me.VLCPnl.BackColor = System.Drawing.Color.Transparent
        Me.VLCPnl.Controls.Add(Me.AxVLCPlugin21)
        Me.VLCPnl.Location = New System.Drawing.Point(13, 14)
        Me.VLCPnl.Name = "VLCPnl"
        Me.VLCPnl.Size = New System.Drawing.Size(322, 216)
        Me.VLCPnl.TabIndex = 0
        '
        'AxVLCPlugin21
        '
        Me.AxVLCPlugin21.Enabled = True
        Me.AxVLCPlugin21.Location = New System.Drawing.Point(-2, -2)
        Me.AxVLCPlugin21.Name = "AxVLCPlugin21"
        Me.AxVLCPlugin21.OcxState = CType(resources.GetObject("AxVLCPlugin21.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxVLCPlugin21.Size = New System.Drawing.Size(324, 215)
        Me.AxVLCPlugin21.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Button4)
        Me.Panel2.Controls.Add(Me.PlayBtn)
        Me.Panel2.Controls.Add(Me.Button7)
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.PauseBtn)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Location = New System.Drawing.Point(374, 262)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(253, 34)
        Me.Panel2.TabIndex = 1
        '
        'Button4
        '
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), System.Drawing.Image)
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.Location = New System.Drawing.Point(219, -1)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(30, 30)
        Me.Button4.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.Button4, "Vollbildmodus")
        Me.Button4.UseVisualStyleBackColor = True
        '
        'PlayBtn
        '
        Me.PlayBtn.BackgroundImage = Global.MovieTown.My.Resources.Resources.Play
        Me.PlayBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PlayBtn.Location = New System.Drawing.Point(88, -1)
        Me.PlayBtn.Name = "PlayBtn"
        Me.PlayBtn.Size = New System.Drawing.Size(30, 30)
        Me.PlayBtn.TabIndex = 7
        Me.PlayBtn.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), System.Drawing.Image)
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button7.Location = New System.Drawing.Point(149, -1)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(30, 30)
        Me.Button7.TabIndex = 9
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), System.Drawing.Image)
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.Location = New System.Drawing.Point(119, -1)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(30, 30)
        Me.Button6.TabIndex = 8
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), System.Drawing.Image)
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button5.Location = New System.Drawing.Point(185, -1)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(30, 30)
        Me.Button5.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.Button5, "Bildverhältnis 16:9")
        Me.Button5.UseVisualStyleBackColor = True
        '
        'PauseBtn
        '
        Me.PauseBtn.BackgroundImage = Global.MovieTown.My.Resources.Resources.Pause
        Me.PauseBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PauseBtn.Location = New System.Drawing.Point(88, -1)
        Me.PauseBtn.Name = "PauseBtn"
        Me.PauseBtn.Size = New System.Drawing.Size(30, 30)
        Me.PauseBtn.TabIndex = 6
        Me.PauseBtn.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImage = Global.MovieTown.My.Resources.Resources._Stop
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Location = New System.Drawing.Point(58, -1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(30, 30)
        Me.Button3.TabIndex = 5
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackgroundImage = Global.MovieTown.My.Resources.Resources.Back
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Location = New System.Drawing.Point(28, -1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(30, 30)
        Me.Button2.TabIndex = 4
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackgroundImage = Global.MovieTown.My.Resources.Resources.FastBack
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Location = New System.Drawing.Point(-2, -1)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(30, 30)
        Me.Button1.TabIndex = 3
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.WesternList)
        Me.Panel3.Controls.Add(Me.AdrianoList)
        Me.Panel3.Controls.Add(Me.SciFiList)
        Me.Panel3.Controls.Add(Me.KlassikList)
        Me.Panel3.Controls.Add(Me.LouisList)
        Me.Panel3.Controls.Add(Me.HorrorList)
        Me.Panel3.Controls.Add(Me.StaloneList)
        Me.Panel3.Controls.Add(Me.JCVDList)
        Me.Panel3.Controls.Add(Me.ComedyList)
        Me.Panel3.Controls.Add(Me.ArniList)
        Me.Panel3.Controls.Add(Me.FantasyList)
        Me.Panel3.Controls.Add(Me.ActionList)
        Me.Panel3.Location = New System.Drawing.Point(9, 17)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(266, 28)
        Me.Panel3.TabIndex = 2
        '
        'ComedyList
        '
        Me.ComedyList.BackColor = System.Drawing.Color.Black
        Me.ComedyList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComedyList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComedyList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ComedyList.FormattingEnabled = True
        Me.ComedyList.Items.AddRange(New Object() {"Die Supernasen", "Zwei Nasen tanken Super", "Zärtliche Chaoten", "Zärtliche Chaoten 2", "Piratensender Powerplay", "Die Einsteiger", "00 Schneider: Jagd auf Nihil Baxter", "00 Schneider: Im Wendekreis der Eidechse", "Fantomas", "Fantomas bedroht die Welt", "Fantomas gegen Interpol", "Ein Zwilling kommt selten allein", "Ach du lieber Harry", "Didi auf vollen Touren", "Didi der Doppelgänger", "Didi der Experte", "Didi und die Rache der Enterbten", "Im Banner der Rouladenkönigin", "Der Schlüssel zur Weibersauna", "Top Secret!", "Otto der Film (im Upload)", "Otto der neue Film", "Der Supercop", "Spaceballs", "Bullyparade: Der Film", "Die Indiana von Cleveland", "Die Indiana von Cleveland II", "Cinderella ´80", "Die Maske", "Mein Partner mit der kalten Schnauze", "South Park: Der Film", "Jumanji: Willkommen im Dschungel", "The Big Lebowski", "Zwei außer Rand und Band"})
        Me.ComedyList.Location = New System.Drawing.Point(0, 0)
        Me.ComedyList.Name = "ComedyList"
        Me.ComedyList.Size = New System.Drawing.Size(262, 25)
        Me.ComedyList.TabIndex = 3
        Me.ComedyList.Visible = False
        '
        'ArniList
        '
        Me.ArniList.BackColor = System.Drawing.Color.Black
        Me.ArniList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ArniList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ArniList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ArniList.FormattingEnabled = True
        Me.ArniList.Items.AddRange(New Object() {"Conan der Barbar", "Conan der Zerstörer", "Last Action Hero", "Predator", "Red Heat", "Red Sonja", "True Lies", "Total Recall", "Terminator", "Terminator 2", "Terminator 3", "Terminator 4", "Terminator 5", "Der City Hai"})
        Me.ArniList.Location = New System.Drawing.Point(0, 0)
        Me.ArniList.Name = "ArniList"
        Me.ArniList.Size = New System.Drawing.Size(262, 25)
        Me.ArniList.TabIndex = 36
        Me.ArniList.Visible = False
        '
        'FantasyList
        '
        Me.FantasyList.BackColor = System.Drawing.Color.Black
        Me.FantasyList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FantasyList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FantasyList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.FantasyList.FormattingEnabled = True
        Me.FantasyList.Items.AddRange(New Object() {"Herr der Ringe: Die Gefährten", "Herr der Ringe: Die zwei Türme", "Herr der Ringe: Die Rückkehr des Königs", "Der Hobbit: Eine unerwartete Reise", "Der Hobbit: Smaugs Einöde", "Der Hobbit: Die Schlacht der fünf Heere", "Die Unendliche Geschichte", "Die Unendliche Geschichte 2", "Highlander: Es kann nur einen geben", "Indiana Jones: Jäger d. v. Schatzes", "Indiana Jones: Der Tempel des Todes", "Indiana Jones: Der letzte Kreuzzug", "Indiana Jones: Königreich d. Kristallschädels", "Auf der Jagd nach dem grünen Diamanten", "Auf der Jagd nach dem Juwel vom Nil", "Conan der Barbar", "Conan der Zerstörer", "Red Sonja", "Der 13te Krieger", "300", "300 - Rise of an Empire", "Batman (1990)", "Batman Forever", "Batman & Robin", "Batman Begins"})
        Me.FantasyList.Location = New System.Drawing.Point(0, 0)
        Me.FantasyList.Name = "FantasyList"
        Me.FantasyList.Size = New System.Drawing.Size(262, 25)
        Me.FantasyList.TabIndex = 28
        Me.FantasyList.Visible = False
        '
        'ActionList
        '
        Me.ActionList.BackColor = System.Drawing.Color.Black
        Me.ActionList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ActionList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ActionList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.ActionList.FormattingEnabled = True
        Me.ActionList.Items.AddRange(New Object() {"Nach eigenen Regeln", "Rookie - Der Anfänger", "True Lies", "From Dusk Till Dawn", "Cliffhanger", "Tango & Cash", "Last Action Hero", "Lethal Weapon", "Lethal Weapon 2", "Lethal Weapon 3", "Lethal Weapon 4", "Red Heat", "Rambo", "Rambo 2", "Rambo 3", "Rambo 4", "Der City Hai", "Stirb Langsam", "Stirb Langsam 2", "Stirb Langsam 3", "Stirb Langsam 4", "Stirb Langsam 5", "Es war einmal in Amerika", "The Goodfellas", "Felon", "Iron Rules: Nach eisernen Regeln", "Pulp Fiction", "Fight Club", "I.D. Undercover", "The Godfather", "The Godfather Part II", "The Godfather Part III", "American Psycho", "American Psycho 2", "Babylon A.D.", "American Psycho HD", "American Psycho 2 HD", "Mad Max 1: Apocalypse", "Mad Max 2: Der Vollstrecker", "Mad Max 3: Jenseits der Donnerkuppel", "Mad Max 4: Fury Road", "Sin City", "HellBoy", "Pfad der Rache", "Natural Born Killers", "Rocky: Part I", "The Colony", "Universal Soldier 2: Die Rückkehr", "Universal Soldier 4: Day of Reckoning", "Made of Steel - Hart wie Stahl"})
        Me.ActionList.Location = New System.Drawing.Point(0, 0)
        Me.ActionList.Name = "ActionList"
        Me.ActionList.Size = New System.Drawing.Size(262, 25)
        Me.ActionList.TabIndex = 3
        '
        'WesternList
        '
        Me.WesternList.BackColor = System.Drawing.Color.Black
        Me.WesternList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.WesternList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WesternList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.WesternList.FormattingEnabled = True
        Me.WesternList.Items.AddRange(New Object() {"Mein Name ist Nobody", "Nobody ist der Größte", "Django", "Django II", "Auch Djangos Kopf hat einen Preis", "Zwiebel-Jack räumt auf", "Winnetou I", "Winnetou II", "Winnetou III", "Unter Geiern", "Im Tal des Todes"})
        Me.WesternList.Location = New System.Drawing.Point(0, 0)
        Me.WesternList.Name = "WesternList"
        Me.WesternList.Size = New System.Drawing.Size(262, 25)
        Me.WesternList.TabIndex = 34
        Me.WesternList.Visible = False
        '
        'AdrianoList
        '
        Me.AdrianoList.BackColor = System.Drawing.Color.Black
        Me.AdrianoList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.AdrianoList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AdrianoList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.AdrianoList.FormattingEnabled = True
        Me.AdrianoList.Items.AddRange(New Object() {"Asso - Ein Himmlischer Spieler", "Bingo Bongo", "Der gezähmte Widerspenstige", "Gib dem Affen Zucker"})
        Me.AdrianoList.Location = New System.Drawing.Point(0, 0)
        Me.AdrianoList.Name = "AdrianoList"
        Me.AdrianoList.Size = New System.Drawing.Size(262, 25)
        Me.AdrianoList.TabIndex = 44
        Me.AdrianoList.Visible = False
        '
        'SciFiList
        '
        Me.SciFiList.BackColor = System.Drawing.Color.Black
        Me.SciFiList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SciFiList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SciFiList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.SciFiList.FormattingEnabled = True
        Me.SciFiList.Items.AddRange(New Object() {"Lost in Space", "Event Horizon", "SW: Episode 1 - Die dunkle Bedrohung", "SW: Episode 2 - Angriff der Klonkrieger", "SW: Episode 3 - Die Rache der Sith", "SW: Episode 4 - Eine neue Hoffnung", "SW: Episode 5 - Das Imperium schlägt zurück", "SW: Episode 6 - Die Rückkehr der Jedi-Ritter", "SW: Episode 7 - Das erwachen der Macht", "SW: Episode 8 - Die letzten Jedi", "The Terminator", "The Terminator 2: Tag der Abrechnung", "The Terminator 3: Rebellion der Maschinen", "The Terminator 4: Die Erlösung", "The Terminator 5: GeneSys", "Total Recall: Die Totale Erinnerung", "Sie Leben! (They Lives)", "The Sixth Sense", "Signs: Zeichen", "Robocop", "Robocop 2", "Robocop 3", "Der Flug des Navigators", "Cowboys & Aliens"})
        Me.SciFiList.Location = New System.Drawing.Point(0, 0)
        Me.SciFiList.Name = "SciFiList"
        Me.SciFiList.Size = New System.Drawing.Size(262, 25)
        Me.SciFiList.TabIndex = 3
        Me.SciFiList.Visible = False
        '
        'KlassikList
        '
        Me.KlassikList.BackColor = System.Drawing.Color.Black
        Me.KlassikList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.KlassikList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KlassikList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.KlassikList.FormattingEnabled = True
        Me.KlassikList.Items.AddRange(New Object() {"Zur Hölle mit den Paukern", "Zum Teufel mit der Penne", "Pepe der Paukerschreck", "Hurra die Schule brennt", "Wir hauen die Pauker in die Pfanne", "Morgen fällt die Schule aus", "Betragen Ungenügend", "Der Hauptmann von Köpenik", "Klein Erna auf dem Jungfernstieg", "Ohne Krimi geht die Mimi nie ins Bett", "Unser Willi ist der beste", "Willi wird das Kind schon schaukeln", "Heintje: Einmal wird die Sonne wieder scheinen", "Heintje: Ein Herz geht auf Reisen", "Heintje: Mein bester Freund", "Hauptsache Ferien (Peter Alexander)", "Wenn der weiße Flieder wieder blüht", "Wenn du bei mir bist (Roy Black)", "Unser Doktor ist der beste", "Immer Ärger mit dem Hochwürden", "Lausbubengeschichten", "Hochwürden drückt ein Auge zu", "Meine Tante, deine Tante", "Das kann doch unseren Willi nicht erschüttern", "Immer diese radfahrer"})
        Me.KlassikList.Location = New System.Drawing.Point(0, 0)
        Me.KlassikList.Name = "KlassikList"
        Me.KlassikList.Size = New System.Drawing.Size(262, 25)
        Me.KlassikList.TabIndex = 45
        Me.KlassikList.Visible = False
        '
        'LouisList
        '
        Me.LouisList.BackColor = System.Drawing.Color.Black
        Me.LouisList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LouisList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LouisList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.LouisList.FormattingEnabled = True
        Me.LouisList.Items.AddRange(New Object() {"Fantomas", "Fantomas bedroht die Welt", "Fantomas gegen Interpol", "Balduin der Ferienschreck", "Balduin der Sonntagsfahrer", "Balduin das Nachtgespenst", "Balduin der Heiratsmuffel"})
        Me.LouisList.Location = New System.Drawing.Point(0, 0)
        Me.LouisList.Name = "LouisList"
        Me.LouisList.Size = New System.Drawing.Size(262, 25)
        Me.LouisList.TabIndex = 44
        Me.LouisList.Visible = False
        '
        'HorrorList
        '
        Me.HorrorList.BackColor = System.Drawing.Color.Black
        Me.HorrorList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HorrorList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HorrorList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.HorrorList.FormattingEnabled = True
        Me.HorrorList.Items.AddRange(New Object() {"Tanz der Teufel", "Tanz der Teufel 2", "Tanz der Teufel 3", "The Evil Dead", "Braindead", "Final Destination", "Final Destination 2", "Final Destination 3", "Final Destination 4", "Final Destination 5", "Maniac Cop", "Maniac Cop 2", "Maniac Cop 3", "Halloween", "Halloween 2", "Halloween 3", "Halloween 4", "Halloween 6", "Halloween 7", "Halloween 8", "Halloween H20", "Halloween Resurrection", "Halloween Remake", "Nightmare on Elm Street 1: Mörderische Träume", "Nightmare on Elm Street 2: Freddys Rache", "Nightmare on Elm Street 3: Dream Warriors", "Nightmare on Elm Street 4: Dream Master", "Nightmare on Elm Street 5: Das Trauma", "Nightmare on Elm Street 6: Freddys Finale", "A Nightmare on Elm Street (2010)", "Leprechaun: Der Killerkobold", "Leprechaun 2: Der Killerkobold kehrt zurück", "Leprechaun 3: Tödliches Spiel in Las Vegas", "Leprechaun 4: Space Platoon", "Leprechaun 5: In The Hood", "Leprechaun 6: Back 2 tha Hood", "Leprechaun 6: Origins", "Mimic (Unrated Version)", "The Fog: Nebel des Grauens", "Seekers", "Sharknado", "Shin Godzille", "Way of the Living Dead", "The Canal", "The Conjouring (im Upload)", "The Conjouring 2", "The Dead 2", "REC 3", "House of the Dead", "Joyride: Spritztour", "The Grudge: Der Fluch", "The Grudge 2", "The Grudge 3", "Wishmaster", "Wishmaster II", "Wishmaster III"})
        Me.HorrorList.Location = New System.Drawing.Point(0, 0)
        Me.HorrorList.Name = "HorrorList"
        Me.HorrorList.Size = New System.Drawing.Size(262, 25)
        Me.HorrorList.TabIndex = 3
        Me.HorrorList.Visible = False
        '
        'StaloneList
        '
        Me.StaloneList.BackColor = System.Drawing.Color.Black
        Me.StaloneList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StaloneList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StaloneList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.StaloneList.FormattingEnabled = True
        Me.StaloneList.Items.AddRange(New Object() {"Tango & Cash", "Rambo", "Rambo 2", "Rambo 3", "Rambo 4", "Cliffhanger", "Rocky Part I"})
        Me.StaloneList.Location = New System.Drawing.Point(0, 0)
        Me.StaloneList.Name = "StaloneList"
        Me.StaloneList.Size = New System.Drawing.Size(262, 25)
        Me.StaloneList.TabIndex = 44
        Me.StaloneList.Visible = False
        '
        'JCVDList
        '
        Me.JCVDList.BackColor = System.Drawing.Color.Black
        Me.JCVDList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.JCVDList.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.JCVDList.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.JCVDList.FormattingEnabled = True
        Me.JCVDList.Items.AddRange(New Object() {"Bloodsport", "Cyborg", "Der Kickboxer", "Double Team", "Geballte Ladung", "Harte Ziele", "Inferno", "Kickboxer - Vergeltung", "Knock Off", "Lionheart", "Maximum Risk", "Mit stählerner Faust", "Ohne Ausweg", "Replicant", "Sudden Death", "Timecop", "Universal Soldier", "Universal Soldier Regeneration", "Derailed - Terror im Zug"})
        Me.JCVDList.Location = New System.Drawing.Point(0, 0)
        Me.JCVDList.Name = "JCVDList"
        Me.JCVDList.Size = New System.Drawing.Size(262, 25)
        Me.JCVDList.TabIndex = 35
        Me.JCVDList.Visible = False
        '
        'ActionListPlayBtn
        '
        Me.ActionListPlayBtn.BackgroundImage = CType(resources.GetObject("ActionListPlayBtn.BackgroundImage"), System.Drawing.Image)
        Me.ActionListPlayBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ActionListPlayBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ActionListPlayBtn.Location = New System.Drawing.Point(190, 49)
        Me.ActionListPlayBtn.Name = "ActionListPlayBtn"
        Me.ActionListPlayBtn.Size = New System.Drawing.Size(75, 26)
        Me.ActionListPlayBtn.TabIndex = 3
        Me.ActionListPlayBtn.Text = "Abspielen"
        Me.ActionListPlayBtn.UseVisualStyleBackColor = True
        Me.ActionListPlayBtn.Visible = False
        '
        'Button9
        '
        Me.Button9.BackgroundImage = CType(resources.GetObject("Button9.BackgroundImage"), System.Drawing.Image)
        Me.Button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button9.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(595, 388)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 26)
        Me.Button9.TabIndex = 4
        Me.Button9.Text = "Beenden"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'WMPPnl
        '
        Me.WMPPnl.BackColor = System.Drawing.Color.Transparent
        Me.WMPPnl.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.WMPPnl.Location = New System.Drawing.Point(13, 14)
        Me.WMPPnl.Name = "WMPPnl"
        Me.WMPPnl.Size = New System.Drawing.Size(322, 213)
        Me.WMPPnl.TabIndex = 5
        Me.WMPPnl.Visible = False
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(0, -2)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(322, 250)
        Me.AxWindowsMediaPlayer1.TabIndex = 0
        '
        'PlayerBtn1
        '
        Me.PlayerBtn1.BackgroundImage = CType(resources.GetObject("PlayerBtn1.BackgroundImage"), System.Drawing.Image)
        Me.PlayerBtn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PlayerBtn1.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlayerBtn1.Location = New System.Drawing.Point(77, 2)
        Me.PlayerBtn1.Name = "PlayerBtn1"
        Me.PlayerBtn1.Size = New System.Drawing.Size(25, 15)
        Me.PlayerBtn1.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.PlayerBtn1, "Player wechseln")
        Me.PlayerBtn1.UseVisualStyleBackColor = True
        '
        'PlayerBtn2
        '
        Me.PlayerBtn2.BackgroundImage = CType(resources.GetObject("PlayerBtn2.BackgroundImage"), System.Drawing.Image)
        Me.PlayerBtn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PlayerBtn2.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlayerBtn2.Location = New System.Drawing.Point(77, 2)
        Me.PlayerBtn2.Name = "PlayerBtn2"
        Me.PlayerBtn2.Size = New System.Drawing.Size(25, 15)
        Me.PlayerBtn2.TabIndex = 7
        Me.PlayerBtn2.UseVisualStyleBackColor = True
        Me.PlayerBtn2.Visible = False
        '
        'PlayerPic1
        '
        Me.PlayerPic1.BackColor = System.Drawing.Color.Transparent
        Me.PlayerPic1.BackgroundImage = CType(resources.GetObject("PlayerPic1.BackgroundImage"), System.Drawing.Image)
        Me.PlayerPic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PlayerPic1.Location = New System.Drawing.Point(20, 20)
        Me.PlayerPic1.Name = "PlayerPic1"
        Me.PlayerPic1.Size = New System.Drawing.Size(30, 30)
        Me.PlayerPic1.TabIndex = 8
        Me.PlayerPic1.TabStop = False
        Me.PlayerPic1.Visible = False
        '
        'PlayerPic2
        '
        Me.PlayerPic2.BackColor = System.Drawing.Color.Transparent
        Me.PlayerPic2.BackgroundImage = CType(resources.GetObject("PlayerPic2.BackgroundImage"), System.Drawing.Image)
        Me.PlayerPic2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PlayerPic2.Location = New System.Drawing.Point(20, 20)
        Me.PlayerPic2.Name = "PlayerPic2"
        Me.PlayerPic2.Size = New System.Drawing.Size(30, 30)
        Me.PlayerPic2.TabIndex = 9
        Me.PlayerPic2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(56, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 16)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "VLC Player"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(1, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 16)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "WMP Player"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.PlayerPic2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.PlayerBtn1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PlayerBtn2)
        Me.Panel1.Controls.Add(Me.PlayerPic1)
        Me.Panel1.Location = New System.Drawing.Point(509, 312)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(119, 60)
        Me.Panel1.TabIndex = 1
        '
        'Button10
        '
        Me.Button10.BackgroundImage = CType(resources.GetObject("Button10.BackgroundImage"), System.Drawing.Image)
        Me.Button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button10.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(32, 12)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(25, 15)
        Me.Button10.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.Button10, "Player wechseln")
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.BackgroundImage = CType(resources.GetObject("Button11.BackgroundImage"), System.Drawing.Image)
        Me.Button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button11.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(32, 33)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(25, 15)
        Me.Button11.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.Button11, "Player wechseln")
        Me.Button11.UseVisualStyleBackColor = True
        '
        'SciFiBtn
        '
        Me.SciFiBtn.BackgroundImage = CType(resources.GetObject("SciFiBtn.BackgroundImage"), System.Drawing.Image)
        Me.SciFiBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SciFiBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SciFiBtn.Location = New System.Drawing.Point(32, 54)
        Me.SciFiBtn.Name = "SciFiBtn"
        Me.SciFiBtn.Size = New System.Drawing.Size(25, 15)
        Me.SciFiBtn.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.SciFiBtn, "Player wechseln")
        Me.SciFiBtn.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.BackgroundImage = CType(resources.GetObject("Button13.BackgroundImage"), System.Drawing.Image)
        Me.Button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button13.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(32, 75)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(25, 15)
        Me.Button13.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.Button13, "Player wechseln")
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.BackgroundImage = CType(resources.GetObject("Button14.BackgroundImage"), System.Drawing.Image)
        Me.Button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button14.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Location = New System.Drawing.Point(12, 75)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(25, 15)
        Me.Button14.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.Button14, "Daten Buffering")
        Me.Button14.UseVisualStyleBackColor = True
        '
        'PosOnBtn
        '
        Me.PosOnBtn.BackgroundImage = CType(resources.GetObject("PosOnBtn.BackgroundImage"), System.Drawing.Image)
        Me.PosOnBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PosOnBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PosOnBtn.Location = New System.Drawing.Point(12, 54)
        Me.PosOnBtn.Name = "PosOnBtn"
        Me.PosOnBtn.Size = New System.Drawing.Size(25, 15)
        Me.PosOnBtn.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.PosOnBtn, "Ein / Aus")
        Me.PosOnBtn.UseVisualStyleBackColor = True
        '
        'VolOnBtn
        '
        Me.VolOnBtn.BackgroundImage = CType(resources.GetObject("VolOnBtn.BackgroundImage"), System.Drawing.Image)
        Me.VolOnBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.VolOnBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VolOnBtn.Location = New System.Drawing.Point(12, 33)
        Me.VolOnBtn.Name = "VolOnBtn"
        Me.VolOnBtn.Size = New System.Drawing.Size(25, 15)
        Me.VolOnBtn.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.VolOnBtn, "Lautstärkeregler einblenden")
        Me.VolOnBtn.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.BackgroundImage = CType(resources.GetObject("Button17.BackgroundImage"), System.Drawing.Image)
        Me.Button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button17.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.Location = New System.Drawing.Point(12, 12)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(25, 15)
        Me.Button17.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.Button17, "Bild Einstellungen")
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.BackgroundImage = CType(resources.GetObject("Button18.BackgroundImage"), System.Drawing.Image)
        Me.Button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button18.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.Location = New System.Drawing.Point(100, 75)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(25, 15)
        Me.Button18.TabIndex = 18
        Me.ToolTip1.SetToolTip(Me.Button18, "System Cache löschen")
        Me.Button18.UseVisualStyleBackColor = True
        '
        'InfoOnBtn
        '
        Me.InfoOnBtn.BackgroundImage = CType(resources.GetObject("InfoOnBtn.BackgroundImage"), System.Drawing.Image)
        Me.InfoOnBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.InfoOnBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InfoOnBtn.Location = New System.Drawing.Point(100, 54)
        Me.InfoOnBtn.Name = "InfoOnBtn"
        Me.InfoOnBtn.Size = New System.Drawing.Size(25, 15)
        Me.InfoOnBtn.TabIndex = 17
        Me.ToolTip1.SetToolTip(Me.InfoOnBtn, "Player wechseln")
        Me.InfoOnBtn.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.BackgroundImage = CType(resources.GetObject("Button21.BackgroundImage"), System.Drawing.Image)
        Me.Button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button21.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.Location = New System.Drawing.Point(100, 12)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(25, 15)
        Me.Button21.TabIndex = 15
        Me.ToolTip1.SetToolTip(Me.Button21, "Bildschirmfoto machen (n.a.)")
        Me.Button21.UseVisualStyleBackColor = True
        '
        'VolOffBtn
        '
        Me.VolOffBtn.BackgroundImage = CType(resources.GetObject("VolOffBtn.BackgroundImage"), System.Drawing.Image)
        Me.VolOffBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.VolOffBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VolOffBtn.Location = New System.Drawing.Point(12, 33)
        Me.VolOffBtn.Name = "VolOffBtn"
        Me.VolOffBtn.Size = New System.Drawing.Size(25, 15)
        Me.VolOffBtn.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.VolOffBtn, "Lautstärkeregler ausblenden")
        Me.VolOffBtn.UseVisualStyleBackColor = True
        Me.VolOffBtn.Visible = False
        '
        'PosOffBtn
        '
        Me.PosOffBtn.BackgroundImage = CType(resources.GetObject("PosOffBtn.BackgroundImage"), System.Drawing.Image)
        Me.PosOffBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PosOffBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PosOffBtn.Location = New System.Drawing.Point(12, 54)
        Me.PosOffBtn.Name = "PosOffBtn"
        Me.PosOffBtn.Size = New System.Drawing.Size(25, 15)
        Me.PosOffBtn.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.PosOffBtn, "Ein / Aus")
        Me.PosOffBtn.UseVisualStyleBackColor = True
        Me.PosOffBtn.Visible = False
        '
        'MenuOff
        '
        Me.MenuOff.BackgroundImage = CType(resources.GetObject("MenuOff.BackgroundImage"), System.Drawing.Image)
        Me.MenuOff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuOff.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuOff.Location = New System.Drawing.Point(9, 67)
        Me.MenuOff.Name = "MenuOff"
        Me.MenuOff.Size = New System.Drawing.Size(25, 15)
        Me.MenuOff.TabIndex = 27
        Me.ToolTip1.SetToolTip(Me.MenuOff, "Menüpanel schließen")
        Me.MenuOff.UseVisualStyleBackColor = True
        Me.MenuOff.Visible = False
        '
        'Button15
        '
        Me.Button15.BackgroundImage = CType(resources.GetObject("Button15.BackgroundImage"), System.Drawing.Image)
        Me.Button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button15.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(32, 96)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(25, 15)
        Me.Button15.TabIndex = 20
        Me.ToolTip1.SetToolTip(Me.Button15, "Player wechseln")
        Me.Button15.UseVisualStyleBackColor = True
        '
        'InfoOffBtn
        '
        Me.InfoOffBtn.BackgroundImage = CType(resources.GetObject("InfoOffBtn.BackgroundImage"), System.Drawing.Image)
        Me.InfoOffBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.InfoOffBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InfoOffBtn.Location = New System.Drawing.Point(100, 54)
        Me.InfoOffBtn.Name = "InfoOffBtn"
        Me.InfoOffBtn.Size = New System.Drawing.Size(25, 15)
        Me.InfoOffBtn.TabIndex = 29
        Me.ToolTip1.SetToolTip(Me.InfoOffBtn, "Film Informationen anzeigen")
        Me.InfoOffBtn.UseVisualStyleBackColor = True
        Me.InfoOffBtn.Visible = False
        '
        'TimerResetBtn
        '
        Me.TimerResetBtn.BackgroundImage = CType(resources.GetObject("TimerResetBtn.BackgroundImage"), System.Drawing.Image)
        Me.TimerResetBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TimerResetBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimerResetBtn.Location = New System.Drawing.Point(10, 41)
        Me.TimerResetBtn.Name = "TimerResetBtn"
        Me.TimerResetBtn.Size = New System.Drawing.Size(15, 15)
        Me.TimerResetBtn.TabIndex = 31
        Me.ToolTip1.SetToolTip(Me.TimerResetBtn, "Timer Reset")
        Me.TimerResetBtn.UseVisualStyleBackColor = True
        '
        'TimerStopBtn
        '
        Me.TimerStopBtn.BackgroundImage = CType(resources.GetObject("TimerStopBtn.BackgroundImage"), System.Drawing.Image)
        Me.TimerStopBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TimerStopBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimerStopBtn.Location = New System.Drawing.Point(31, 41)
        Me.TimerStopBtn.Name = "TimerStopBtn"
        Me.TimerStopBtn.Size = New System.Drawing.Size(15, 15)
        Me.TimerStopBtn.TabIndex = 32
        Me.ToolTip1.SetToolTip(Me.TimerStopBtn, "Timer Stop")
        Me.TimerStopBtn.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.BackgroundImage = CType(resources.GetObject("Button12.BackgroundImage"), System.Drawing.Image)
        Me.Button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button12.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(32, 117)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(25, 15)
        Me.Button12.TabIndex = 24
        Me.ToolTip1.SetToolTip(Me.Button12, "Player wechseln")
        Me.Button12.UseVisualStyleBackColor = True
        '
        'KlassikBtn
        '
        Me.KlassikBtn.BackgroundImage = CType(resources.GetObject("KlassikBtn.BackgroundImage"), System.Drawing.Image)
        Me.KlassikBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.KlassikBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KlassikBtn.Location = New System.Drawing.Point(32, 117)
        Me.KlassikBtn.Name = "KlassikBtn"
        Me.KlassikBtn.Size = New System.Drawing.Size(25, 15)
        Me.KlassikBtn.TabIndex = 24
        Me.ToolTip1.SetToolTip(Me.KlassikBtn, "Player wechseln")
        Me.KlassikBtn.UseVisualStyleBackColor = True
        '
        'LouisBtn
        '
        Me.LouisBtn.BackgroundImage = CType(resources.GetObject("LouisBtn.BackgroundImage"), System.Drawing.Image)
        Me.LouisBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.LouisBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LouisBtn.Location = New System.Drawing.Point(32, 96)
        Me.LouisBtn.Name = "LouisBtn"
        Me.LouisBtn.Size = New System.Drawing.Size(25, 15)
        Me.LouisBtn.TabIndex = 20
        Me.ToolTip1.SetToolTip(Me.LouisBtn, "Player wechseln")
        Me.LouisBtn.UseVisualStyleBackColor = True
        '
        'AdrianoBtn
        '
        Me.AdrianoBtn.BackgroundImage = CType(resources.GetObject("AdrianoBtn.BackgroundImage"), System.Drawing.Image)
        Me.AdrianoBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.AdrianoBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AdrianoBtn.Location = New System.Drawing.Point(32, 75)
        Me.AdrianoBtn.Name = "AdrianoBtn"
        Me.AdrianoBtn.Size = New System.Drawing.Size(25, 15)
        Me.AdrianoBtn.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.AdrianoBtn, "Player wechseln")
        Me.AdrianoBtn.UseVisualStyleBackColor = True
        '
        'ArniBtn
        '
        Me.ArniBtn.BackgroundImage = CType(resources.GetObject("ArniBtn.BackgroundImage"), System.Drawing.Image)
        Me.ArniBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ArniBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ArniBtn.Location = New System.Drawing.Point(32, 54)
        Me.ArniBtn.Name = "ArniBtn"
        Me.ArniBtn.Size = New System.Drawing.Size(25, 15)
        Me.ArniBtn.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.ArniBtn, "Player wechseln")
        Me.ArniBtn.UseVisualStyleBackColor = True
        '
        'StaloneBtn
        '
        Me.StaloneBtn.BackgroundImage = CType(resources.GetObject("StaloneBtn.BackgroundImage"), System.Drawing.Image)
        Me.StaloneBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.StaloneBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StaloneBtn.Location = New System.Drawing.Point(32, 33)
        Me.StaloneBtn.Name = "StaloneBtn"
        Me.StaloneBtn.Size = New System.Drawing.Size(25, 15)
        Me.StaloneBtn.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.StaloneBtn, "Player wechseln")
        Me.StaloneBtn.UseVisualStyleBackColor = True
        '
        'ExtraOnBtn
        '
        Me.ExtraOnBtn.BackgroundImage = CType(resources.GetObject("ExtraOnBtn.BackgroundImage"), System.Drawing.Image)
        Me.ExtraOnBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ExtraOnBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtraOnBtn.Location = New System.Drawing.Point(9, 48)
        Me.ExtraOnBtn.Name = "ExtraOnBtn"
        Me.ExtraOnBtn.Size = New System.Drawing.Size(25, 15)
        Me.ExtraOnBtn.TabIndex = 42
        Me.ToolTip1.SetToolTip(Me.ExtraOnBtn, "Extra Panel anzeigen")
        Me.ExtraOnBtn.UseVisualStyleBackColor = True
        '
        'ExtraOffBtn
        '
        Me.ExtraOffBtn.BackgroundImage = CType(resources.GetObject("ExtraOffBtn.BackgroundImage"), System.Drawing.Image)
        Me.ExtraOffBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ExtraOffBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtraOffBtn.Location = New System.Drawing.Point(9, 48)
        Me.ExtraOffBtn.Name = "ExtraOffBtn"
        Me.ExtraOffBtn.Size = New System.Drawing.Size(25, 15)
        Me.ExtraOffBtn.TabIndex = 43
        Me.ToolTip1.SetToolTip(Me.ExtraOffBtn, "Extra Panel ausblenden")
        Me.ExtraOffBtn.UseVisualStyleBackColor = True
        Me.ExtraOffBtn.Visible = False
        '
        'UpdateBtn
        '
        Me.UpdateBtn.BackgroundImage = CType(resources.GetObject("UpdateBtn.BackgroundImage"), System.Drawing.Image)
        Me.UpdateBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.UpdateBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateBtn.Location = New System.Drawing.Point(100, 33)
        Me.UpdateBtn.Name = "UpdateBtn"
        Me.UpdateBtn.Size = New System.Drawing.Size(25, 15)
        Me.UpdateBtn.TabIndex = 46
        Me.ToolTip1.SetToolTip(Me.UpdateBtn, "Programm aktualisieren")
        Me.UpdateBtn.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.WesternPic2)
        Me.Panel4.Controls.Add(Me.WesternPic1)
        Me.Panel4.Controls.Add(Me.Label20)
        Me.Panel4.Controls.Add(Me.Button12)
        Me.Panel4.Controls.Add(Me.FantasyPic2)
        Me.Panel4.Controls.Add(Me.FantasyPic1)
        Me.Panel4.Controls.Add(Me.Label15)
        Me.Panel4.Controls.Add(Me.Button15)
        Me.Panel4.Controls.Add(Me.ActionPic2)
        Me.Panel4.Controls.Add(Me.ComedyPic2)
        Me.Panel4.Controls.Add(Me.HorrorPic2)
        Me.Panel4.Controls.Add(Me.HorrorPic1)
        Me.Panel4.Controls.Add(Me.SciFiPic2)
        Me.Panel4.Controls.Add(Me.ComedyPic1)
        Me.Panel4.Controls.Add(Me.ActionPic1)
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.Button13)
        Me.Panel4.Controls.Add(Me.SciFiBtn)
        Me.Panel4.Controls.Add(Me.Button11)
        Me.Panel4.Controls.Add(Me.Button10)
        Me.Panel4.Controls.Add(Me.SciFiPic1)
        Me.Panel4.Location = New System.Drawing.Point(12, 123)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(124, 147)
        Me.Panel4.TabIndex = 6
        '
        'WesternPic2
        '
        Me.WesternPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.WesternPic2.Location = New System.Drawing.Point(16, 117)
        Me.WesternPic2.Name = "WesternPic2"
        Me.WesternPic2.Size = New System.Drawing.Size(10, 10)
        Me.WesternPic2.TabIndex = 27
        Me.WesternPic2.TabStop = False
        Me.WesternPic2.Visible = False
        '
        'WesternPic1
        '
        Me.WesternPic1.BackColor = System.Drawing.Color.Silver
        Me.WesternPic1.Location = New System.Drawing.Point(16, 117)
        Me.WesternPic1.Name = "WesternPic1"
        Me.WesternPic1.Size = New System.Drawing.Size(10, 10)
        Me.WesternPic1.TabIndex = 26
        Me.WesternPic1.TabStop = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(63, 116)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(50, 16)
        Me.Label20.TabIndex = 25
        Me.Label20.Text = "Western"
        '
        'FantasyPic2
        '
        Me.FantasyPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.FantasyPic2.Location = New System.Drawing.Point(16, 96)
        Me.FantasyPic2.Name = "FantasyPic2"
        Me.FantasyPic2.Size = New System.Drawing.Size(10, 10)
        Me.FantasyPic2.TabIndex = 23
        Me.FantasyPic2.TabStop = False
        Me.FantasyPic2.Visible = False
        '
        'FantasyPic1
        '
        Me.FantasyPic1.BackColor = System.Drawing.Color.Silver
        Me.FantasyPic1.Location = New System.Drawing.Point(16, 96)
        Me.FantasyPic1.Name = "FantasyPic1"
        Me.FantasyPic1.Size = New System.Drawing.Size(10, 10)
        Me.FantasyPic1.TabIndex = 22
        Me.FantasyPic1.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(63, 95)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(46, 16)
        Me.Label15.TabIndex = 21
        Me.Label15.Text = "Fantasy"
        '
        'ActionPic2
        '
        Me.ActionPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.ActionPic2.Location = New System.Drawing.Point(16, 12)
        Me.ActionPic2.Name = "ActionPic2"
        Me.ActionPic2.Size = New System.Drawing.Size(10, 10)
        Me.ActionPic2.TabIndex = 19
        Me.ActionPic2.TabStop = False
        Me.ActionPic2.Visible = False
        '
        'ComedyPic2
        '
        Me.ComedyPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.ComedyPic2.Location = New System.Drawing.Point(16, 33)
        Me.ComedyPic2.Name = "ComedyPic2"
        Me.ComedyPic2.Size = New System.Drawing.Size(10, 10)
        Me.ComedyPic2.TabIndex = 19
        Me.ComedyPic2.TabStop = False
        Me.ComedyPic2.Visible = False
        '
        'HorrorPic2
        '
        Me.HorrorPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.HorrorPic2.Location = New System.Drawing.Point(16, 75)
        Me.HorrorPic2.Name = "HorrorPic2"
        Me.HorrorPic2.Size = New System.Drawing.Size(10, 10)
        Me.HorrorPic2.TabIndex = 18
        Me.HorrorPic2.TabStop = False
        Me.HorrorPic2.Visible = False
        '
        'HorrorPic1
        '
        Me.HorrorPic1.BackColor = System.Drawing.Color.Silver
        Me.HorrorPic1.Location = New System.Drawing.Point(16, 75)
        Me.HorrorPic1.Name = "HorrorPic1"
        Me.HorrorPic1.Size = New System.Drawing.Size(10, 10)
        Me.HorrorPic1.TabIndex = 17
        Me.HorrorPic1.TabStop = False
        '
        'SciFiPic2
        '
        Me.SciFiPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.SciFiPic2.Location = New System.Drawing.Point(16, 54)
        Me.SciFiPic2.Name = "SciFiPic2"
        Me.SciFiPic2.Size = New System.Drawing.Size(10, 10)
        Me.SciFiPic2.TabIndex = 16
        Me.SciFiPic2.TabStop = False
        '
        'ComedyPic1
        '
        Me.ComedyPic1.BackColor = System.Drawing.Color.DarkGray
        Me.ComedyPic1.Location = New System.Drawing.Point(16, 33)
        Me.ComedyPic1.Name = "ComedyPic1"
        Me.ComedyPic1.Size = New System.Drawing.Size(10, 10)
        Me.ComedyPic1.TabIndex = 15
        Me.ComedyPic1.TabStop = False
        '
        'ActionPic1
        '
        Me.ActionPic1.BackColor = System.Drawing.Color.DarkGray
        Me.ActionPic1.Location = New System.Drawing.Point(16, 12)
        Me.ActionPic1.Name = "ActionPic1"
        Me.ActionPic1.Size = New System.Drawing.Size(10, 10)
        Me.ActionPic1.TabIndex = 10
        Me.ActionPic1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(63, 74)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 16)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Horror"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(63, 53)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(33, 16)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "SciFi"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(63, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 16)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Comedy"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(63, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 16)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Action"
        '
        'SciFiPic1
        '
        Me.SciFiPic1.BackColor = System.Drawing.Color.Silver
        Me.SciFiPic1.Location = New System.Drawing.Point(16, 54)
        Me.SciFiPic1.Name = "SciFiPic1"
        Me.SciFiPic1.Size = New System.Drawing.Size(10, 10)
        Me.SciFiPic1.TabIndex = 19
        Me.SciFiPic1.TabStop = False
        '
        'ActionPnl
        '
        Me.ActionPnl.BackColor = System.Drawing.Color.Transparent
        Me.ActionPnl.BackgroundImage = CType(resources.GetObject("ActionPnl.BackgroundImage"), System.Drawing.Image)
        Me.ActionPnl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ActionPnl.Controls.Add(Me.Label32)
        Me.ActionPnl.Controls.Add(Me.Label34)
        Me.ActionPnl.Controls.Add(Me.Button8)
        Me.ActionPnl.Controls.Add(Me.HorrorListPlayBtn)
        Me.ActionPnl.Controls.Add(Me.ExtraOffBtn)
        Me.ActionPnl.Controls.Add(Me.ExtraOnBtn)
        Me.ActionPnl.Controls.Add(Me.FantasyListPlayBtn)
        Me.ActionPnl.Controls.Add(Me.SciFiListPlayBtn)
        Me.ActionPnl.Controls.Add(Me.Panel3)
        Me.ActionPnl.Controls.Add(Me.ComedyListPlayBtn)
        Me.ActionPnl.Controls.Add(Me.ActionListPlayBtn)
        Me.ActionPnl.Controls.Add(Me.MenuOff)
        Me.ActionPnl.Controls.Add(Me.MenuOn)
        Me.ActionPnl.Location = New System.Drawing.Point(12, 5)
        Me.ActionPnl.Name = "ActionPnl"
        Me.ActionPnl.Size = New System.Drawing.Size(282, 85)
        Me.ActionPnl.TabIndex = 7
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(37, 66)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(36, 16)
        Me.Label32.TabIndex = 28
        Me.Label32.Text = "Menü"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(36, 48)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(38, 16)
        Me.Label34.TabIndex = 44
        Me.Label34.Text = "Extras"
        '
        'Button8
        '
        Me.Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), System.Drawing.Image)
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button8.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(190, 49)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 26)
        Me.Button8.TabIndex = 37
        Me.Button8.Text = "Abspielen"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'HorrorListPlayBtn
        '
        Me.HorrorListPlayBtn.BackgroundImage = CType(resources.GetObject("HorrorListPlayBtn.BackgroundImage"), System.Drawing.Image)
        Me.HorrorListPlayBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.HorrorListPlayBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HorrorListPlayBtn.Location = New System.Drawing.Point(190, 48)
        Me.HorrorListPlayBtn.Name = "HorrorListPlayBtn"
        Me.HorrorListPlayBtn.Size = New System.Drawing.Size(75, 26)
        Me.HorrorListPlayBtn.TabIndex = 36
        Me.HorrorListPlayBtn.Text = "Abspielen"
        Me.HorrorListPlayBtn.UseVisualStyleBackColor = True
        Me.HorrorListPlayBtn.Visible = False
        '
        'FantasyListPlayBtn
        '
        Me.FantasyListPlayBtn.BackgroundImage = CType(resources.GetObject("FantasyListPlayBtn.BackgroundImage"), System.Drawing.Image)
        Me.FantasyListPlayBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.FantasyListPlayBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FantasyListPlayBtn.Location = New System.Drawing.Point(190, 49)
        Me.FantasyListPlayBtn.Name = "FantasyListPlayBtn"
        Me.FantasyListPlayBtn.Size = New System.Drawing.Size(75, 26)
        Me.FantasyListPlayBtn.TabIndex = 37
        Me.FantasyListPlayBtn.Text = "Abspielen"
        Me.FantasyListPlayBtn.UseVisualStyleBackColor = True
        Me.FantasyListPlayBtn.Visible = False
        '
        'SciFiListPlayBtn
        '
        Me.SciFiListPlayBtn.BackgroundImage = CType(resources.GetObject("SciFiListPlayBtn.BackgroundImage"), System.Drawing.Image)
        Me.SciFiListPlayBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SciFiListPlayBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SciFiListPlayBtn.Location = New System.Drawing.Point(190, 49)
        Me.SciFiListPlayBtn.Name = "SciFiListPlayBtn"
        Me.SciFiListPlayBtn.Size = New System.Drawing.Size(75, 26)
        Me.SciFiListPlayBtn.TabIndex = 35
        Me.SciFiListPlayBtn.Text = "Abspielen"
        Me.SciFiListPlayBtn.UseVisualStyleBackColor = True
        Me.SciFiListPlayBtn.Visible = False
        '
        'ComedyListPlayBtn
        '
        Me.ComedyListPlayBtn.BackgroundImage = CType(resources.GetObject("ComedyListPlayBtn.BackgroundImage"), System.Drawing.Image)
        Me.ComedyListPlayBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ComedyListPlayBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComedyListPlayBtn.Location = New System.Drawing.Point(190, 49)
        Me.ComedyListPlayBtn.Name = "ComedyListPlayBtn"
        Me.ComedyListPlayBtn.Size = New System.Drawing.Size(75, 26)
        Me.ComedyListPlayBtn.TabIndex = 34
        Me.ComedyListPlayBtn.Text = "Abspielen"
        Me.ComedyListPlayBtn.UseVisualStyleBackColor = True
        Me.ComedyListPlayBtn.Visible = False
        '
        'MenuOn
        '
        Me.MenuOn.BackgroundImage = CType(resources.GetObject("MenuOn.BackgroundImage"), System.Drawing.Image)
        Me.MenuOn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuOn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuOn.Location = New System.Drawing.Point(9, 67)
        Me.MenuOn.Name = "MenuOn"
        Me.MenuOn.Size = New System.Drawing.Size(25, 15)
        Me.MenuOn.TabIndex = 26
        Me.MenuOn.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.InfoOffBtn)
        Me.Panel5.Controls.Add(Me.PosOffBtn)
        Me.Panel5.Controls.Add(Me.VolOffBtn)
        Me.Panel5.Controls.Add(Me.UpdateBtn)
        Me.Panel5.Controls.Add(Me.Label11)
        Me.Panel5.Controls.Add(Me.Label12)
        Me.Panel5.Controls.Add(Me.Label13)
        Me.Panel5.Controls.Add(Me.Label14)
        Me.Panel5.Controls.Add(Me.Button18)
        Me.Panel5.Controls.Add(Me.InfoOnBtn)
        Me.Panel5.Controls.Add(Me.Button21)
        Me.Panel5.Controls.Add(Me.Label7)
        Me.Panel5.Controls.Add(Me.Label8)
        Me.Panel5.Controls.Add(Me.Label9)
        Me.Panel5.Controls.Add(Me.Label10)
        Me.Panel5.Controls.Add(Me.Button14)
        Me.Panel5.Controls.Add(Me.PosOnBtn)
        Me.Panel5.Controls.Add(Me.VolOnBtn)
        Me.Panel5.Controls.Add(Me.Button17)
        Me.Panel5.Location = New System.Drawing.Point(46, 289)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(218, 125)
        Me.Panel5.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(131, 74)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 16)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Cache leeren"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(131, 53)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(32, 16)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Infos"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(131, 32)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 16)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Update"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(131, 12)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 16)
        Me.Label14.TabIndex = 19
        Me.Label14.Text = "Screenshot"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(43, 74)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 16)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Buffering"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(43, 53)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 16)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Position"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(43, 32)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(25, 16)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Ton"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(43, 12)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(27, 16)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Bild"
        '
        'VolPnl
        '
        Me.VolPnl.BackColor = System.Drawing.Color.Transparent
        Me.VolPnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.VolPnl.Controls.Add(Me.TrackBar2)
        Me.VolPnl.Controls.Add(Me.TrackBar1)
        Me.VolPnl.Location = New System.Drawing.Point(286, 302)
        Me.VolPnl.Name = "VolPnl"
        Me.VolPnl.Size = New System.Drawing.Size(217, 50)
        Me.VolPnl.TabIndex = 9
        Me.VolPnl.Visible = False
        '
        'TrackBar2
        '
        Me.TrackBar2.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.TrackBar2.LargeChange = 2
        Me.TrackBar2.Location = New System.Drawing.Point(-2, -1)
        Me.TrackBar2.Name = "TrackBar2"
        Me.TrackBar2.Size = New System.Drawing.Size(215, 45)
        Me.TrackBar2.TabIndex = 10
        Me.TrackBar2.Visible = False
        '
        'TrackBar1
        '
        Me.TrackBar1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.TrackBar1.LargeChange = 2
        Me.TrackBar1.Location = New System.Drawing.Point(0, 0)
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(215, 45)
        Me.TrackBar1.TabIndex = 0
        Me.TrackBar1.Value = 10
        '
        'BufferBarOff
        '
        Me.BufferBarOff.Location = New System.Drawing.Point(374, 247)
        Me.BufferBarOff.Name = "BufferBarOff"
        Me.BufferBarOff.Size = New System.Drawing.Size(251, 10)
        Me.BufferBarOff.Step = 2
        Me.BufferBarOff.TabIndex = 23
        '
        'BufferBarOn
        '
        Me.BufferBarOn.Location = New System.Drawing.Point(374, 247)
        Me.BufferBarOn.Name = "BufferBarOn"
        Me.BufferBarOn.Size = New System.Drawing.Size(251, 10)
        Me.BufferBarOn.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.BufferBarOn.TabIndex = 24
        Me.BufferBarOn.Visible = False
        '
        'MenuPnlHider
        '
        Me.MenuPnlHider.BackColor = System.Drawing.Color.Transparent
        Me.MenuPnlHider.Controls.Add(Me.Panel11)
        Me.MenuPnlHider.Location = New System.Drawing.Point(46, 289)
        Me.MenuPnlHider.Name = "MenuPnlHider"
        Me.MenuPnlHider.Size = New System.Drawing.Size(218, 125)
        Me.MenuPnlHider.TabIndex = 25
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.Transparent
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel11.Controls.Add(Me.PictureBox2)
        Me.Panel11.Controls.Add(Me.PictureBox1)
        Me.Panel11.Controls.Add(Me.Label33)
        Me.Panel11.Location = New System.Drawing.Point(3, 27)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(212, 74)
        Me.Panel11.TabIndex = 30
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(5, 38)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(194, 25)
        Me.PictureBox2.TabIndex = 29
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(-2, -2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(210, 46)
        Me.PictureBox1.TabIndex = 28
        Me.PictureBox1.TabStop = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(-11, -8)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(38, 16)
        Me.Label33.TabIndex = 29
        Me.Label33.Text = "Extras"
        '
        'InfoPnl
        '
        Me.InfoPnl.BackColor = System.Drawing.Color.Transparent
        Me.InfoPnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.InfoPnl.Controls.Add(Me.Panel7)
        Me.InfoPnl.Controls.Add(Me.Label19)
        Me.InfoPnl.Controls.Add(Me.Label18)
        Me.InfoPnl.Controls.Add(Me.Label17)
        Me.InfoPnl.Controls.Add(Me.Label16)
        Me.InfoPnl.Location = New System.Drawing.Point(291, 299)
        Me.InfoPnl.Name = "InfoPnl"
        Me.InfoPnl.Size = New System.Drawing.Size(203, 112)
        Me.InfoPnl.TabIndex = 28
        Me.InfoPnl.Visible = False
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Beige
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel7.Controls.Add(Me.IMDBlbl)
        Me.Panel7.Controls.Add(Me.Yearlbl)
        Me.Panel7.Controls.Add(Me.Genrelbl)
        Me.Panel7.Controls.Add(Me.Durationlbl)
        Me.Panel7.Location = New System.Drawing.Point(54, 8)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(126, 90)
        Me.Panel7.TabIndex = 16
        '
        'IMDBlbl
        '
        Me.IMDBlbl.AutoSize = True
        Me.IMDBlbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IMDBlbl.Location = New System.Drawing.Point(3, 65)
        Me.IMDBlbl.Name = "IMDBlbl"
        Me.IMDBlbl.Size = New System.Drawing.Size(17, 16)
        Me.IMDBlbl.TabIndex = 30
        Me.IMDBlbl.Text = "..."
        Me.IMDBlbl.Visible = False
        '
        'Yearlbl
        '
        Me.Yearlbl.AutoSize = True
        Me.Yearlbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Yearlbl.Location = New System.Drawing.Point(3, 45)
        Me.Yearlbl.Name = "Yearlbl"
        Me.Yearlbl.Size = New System.Drawing.Size(17, 16)
        Me.Yearlbl.TabIndex = 30
        Me.Yearlbl.Text = "..."
        Me.Yearlbl.Visible = False
        '
        'Genrelbl
        '
        Me.Genrelbl.AutoSize = True
        Me.Genrelbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Genrelbl.Location = New System.Drawing.Point(3, 25)
        Me.Genrelbl.Name = "Genrelbl"
        Me.Genrelbl.Size = New System.Drawing.Size(17, 16)
        Me.Genrelbl.TabIndex = 30
        Me.Genrelbl.Text = "..."
        Me.Genrelbl.Visible = False
        '
        'Durationlbl
        '
        Me.Durationlbl.AutoSize = True
        Me.Durationlbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Durationlbl.Location = New System.Drawing.Point(3, 5)
        Me.Durationlbl.Name = "Durationlbl"
        Me.Durationlbl.Size = New System.Drawing.Size(17, 16)
        Me.Durationlbl.TabIndex = 29
        Me.Durationlbl.Text = "..."
        Me.Durationlbl.Visible = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(14, 75)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(36, 16)
        Me.Label19.TabIndex = 15
        Me.Label19.Text = "IMDB"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(23, 55)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(28, 16)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "Jahr"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(12, 35)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 16)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "Genre"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(12, 15)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(38, 16)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Dauer"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Transparent
        Me.Panel6.BackgroundImage = CType(resources.GetObject("Panel6.BackgroundImage"), System.Drawing.Image)
        Me.Panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel6.Controls.Add(Me.ActionPnl)
        Me.Panel6.Location = New System.Drawing.Point(9, 11)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(307, 96)
        Me.Panel6.TabIndex = 29
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Transparent
        Me.Panel8.BackgroundImage = CType(resources.GetObject("Panel8.BackgroundImage"), System.Drawing.Image)
        Me.Panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel8.Controls.Add(Me.WMPPnl)
        Me.Panel8.Controls.Add(Me.VLCPnl)
        Me.Panel8.Location = New System.Drawing.Point(322, 1)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(352, 240)
        Me.Panel8.TabIndex = 29
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Beige
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel9.Controls.Add(Me.Milliseklbl)
        Me.Panel9.Controls.Add(Me.Label22)
        Me.Panel9.Controls.Add(Me.Seklbl)
        Me.Panel9.Controls.Add(Me.Label21)
        Me.Panel9.Controls.Add(Me.Minlbl)
        Me.Panel9.Location = New System.Drawing.Point(8, 6)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(129, 30)
        Me.Panel9.TabIndex = 30
        '
        'Milliseklbl
        '
        Me.Milliseklbl.AutoSize = True
        Me.Milliseklbl.BackColor = System.Drawing.Color.Transparent
        Me.Milliseklbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Milliseklbl.Location = New System.Drawing.Point(78, 5)
        Me.Milliseklbl.Name = "Milliseklbl"
        Me.Milliseklbl.Size = New System.Drawing.Size(28, 21)
        Me.Milliseklbl.TabIndex = 35
        Me.Milliseklbl.Text = "00"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(71, 4)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(14, 21)
        Me.Label22.TabIndex = 34
        Me.Label22.Text = ":"
        '
        'Seklbl
        '
        Me.Seklbl.AutoSize = True
        Me.Seklbl.BackColor = System.Drawing.Color.Transparent
        Me.Seklbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Seklbl.Location = New System.Drawing.Point(49, 5)
        Me.Seklbl.Name = "Seklbl"
        Me.Seklbl.Size = New System.Drawing.Size(28, 21)
        Me.Seklbl.TabIndex = 33
        Me.Seklbl.Text = "00"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(42, 4)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(14, 21)
        Me.Label21.TabIndex = 32
        Me.Label21.Text = ":"
        '
        'Minlbl
        '
        Me.Minlbl.AutoSize = True
        Me.Minlbl.BackColor = System.Drawing.Color.Transparent
        Me.Minlbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Minlbl.Location = New System.Drawing.Point(20, 5)
        Me.Minlbl.Name = "Minlbl"
        Me.Minlbl.Size = New System.Drawing.Size(28, 21)
        Me.Minlbl.TabIndex = 31
        Me.Minlbl.Text = "00"
        '
        'Min
        '
        Me.Min.Interval = 60000
        '
        'Sek
        '
        Me.Sek.Interval = 1000
        '
        'Millisek
        '
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Transparent
        Me.Panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel10.Controls.Add(Me.Panel9)
        Me.Panel10.Controls.Add(Me.TimerStopBtn)
        Me.Panel10.Controls.Add(Me.TimerResetBtn)
        Me.Panel10.Location = New System.Drawing.Point(153, 123)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(150, 64)
        Me.Panel10.TabIndex = 33
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.Beige
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel12.Controls.Add(Me.Label31)
        Me.Panel12.Controls.Add(Me.Filenamelbl)
        Me.Panel12.Controls.Add(Me.Label23)
        Me.Panel12.ForeColor = System.Drawing.Color.Black
        Me.Panel12.Location = New System.Drawing.Point(150, 198)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(153, 72)
        Me.Panel12.TabIndex = 38
        Me.Panel12.Visible = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(3, 41)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(17, 16)
        Me.Label31.TabIndex = 41
        Me.Label31.Text = "..."
        '
        'Filenamelbl
        '
        Me.Filenamelbl.AutoSize = True
        Me.Filenamelbl.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Filenamelbl.Location = New System.Drawing.Point(3, 21)
        Me.Filenamelbl.Name = "Filenamelbl"
        Me.Filenamelbl.Size = New System.Drawing.Size(17, 16)
        Me.Filenamelbl.TabIndex = 40
        Me.Filenamelbl.Text = "..."
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(3, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(63, 15)
        Me.Label23.TabIndex = 39
        Me.Label23.Text = "Dateiname:"
        '
        'BarBtn1
        '
        Me.BarBtn1.BackgroundImage = CType(resources.GetObject("BarBtn1.BackgroundImage"), System.Drawing.Image)
        Me.BarBtn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BarBtn1.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BarBtn1.Location = New System.Drawing.Point(645, 247)
        Me.BarBtn1.Name = "BarBtn1"
        Me.BarBtn1.Size = New System.Drawing.Size(25, 15)
        Me.BarBtn1.TabIndex = 39
        Me.BarBtn1.UseVisualStyleBackColor = True
        '
        'BarBtn2
        '
        Me.BarBtn2.BackgroundImage = CType(resources.GetObject("BarBtn2.BackgroundImage"), System.Drawing.Image)
        Me.BarBtn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BarBtn2.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BarBtn2.Location = New System.Drawing.Point(645, 247)
        Me.BarBtn2.Name = "BarBtn2"
        Me.BarBtn2.Size = New System.Drawing.Size(25, 15)
        Me.BarBtn2.TabIndex = 40
        Me.BarBtn2.UseVisualStyleBackColor = True
        Me.BarBtn2.Visible = False
        '
        'ExtraPnl
        '
        Me.ExtraPnl.BackColor = System.Drawing.Color.Transparent
        Me.ExtraPnl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ExtraPnl.Controls.Add(Me.KlassikPic2)
        Me.ExtraPnl.Controls.Add(Me.KlassikPic1)
        Me.ExtraPnl.Controls.Add(Me.Label24)
        Me.ExtraPnl.Controls.Add(Me.KlassikBtn)
        Me.ExtraPnl.Controls.Add(Me.LouisPic2)
        Me.ExtraPnl.Controls.Add(Me.LouisPic1)
        Me.ExtraPnl.Controls.Add(Me.Label25)
        Me.ExtraPnl.Controls.Add(Me.LouisBtn)
        Me.ExtraPnl.Controls.Add(Me.JCVDPic2)
        Me.ExtraPnl.Controls.Add(Me.StalonePic2)
        Me.ExtraPnl.Controls.Add(Me.AdrianoPic2)
        Me.ExtraPnl.Controls.Add(Me.AdrianoPic1)
        Me.ExtraPnl.Controls.Add(Me.ArniPic2)
        Me.ExtraPnl.Controls.Add(Me.StalonePic1)
        Me.ExtraPnl.Controls.Add(Me.JCVDPic1)
        Me.ExtraPnl.Controls.Add(Me.Label26)
        Me.ExtraPnl.Controls.Add(Me.Label27)
        Me.ExtraPnl.Controls.Add(Me.Label28)
        Me.ExtraPnl.Controls.Add(Me.Label29)
        Me.ExtraPnl.Controls.Add(Me.AdrianoBtn)
        Me.ExtraPnl.Controls.Add(Me.ArniBtn)
        Me.ExtraPnl.Controls.Add(Me.StaloneBtn)
        Me.ExtraPnl.Controls.Add(Me.JCVDBtn)
        Me.ExtraPnl.Controls.Add(Me.ArniPic1)
        Me.ExtraPnl.Location = New System.Drawing.Point(9, 123)
        Me.ExtraPnl.Name = "ExtraPnl"
        Me.ExtraPnl.Size = New System.Drawing.Size(294, 147)
        Me.ExtraPnl.TabIndex = 41
        Me.ExtraPnl.Visible = False
        '
        'KlassikPic2
        '
        Me.KlassikPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.KlassikPic2.Location = New System.Drawing.Point(16, 117)
        Me.KlassikPic2.Name = "KlassikPic2"
        Me.KlassikPic2.Size = New System.Drawing.Size(10, 10)
        Me.KlassikPic2.TabIndex = 27
        Me.KlassikPic2.TabStop = False
        Me.KlassikPic2.Visible = False
        '
        'KlassikPic1
        '
        Me.KlassikPic1.BackColor = System.Drawing.Color.Silver
        Me.KlassikPic1.Location = New System.Drawing.Point(16, 117)
        Me.KlassikPic1.Name = "KlassikPic1"
        Me.KlassikPic1.Size = New System.Drawing.Size(10, 10)
        Me.KlassikPic1.TabIndex = 26
        Me.KlassikPic1.TabStop = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(63, 116)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(53, 16)
        Me.Label24.TabIndex = 25
        Me.Label24.Text = "Klassiker"
        '
        'LouisPic2
        '
        Me.LouisPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.LouisPic2.Location = New System.Drawing.Point(16, 96)
        Me.LouisPic2.Name = "LouisPic2"
        Me.LouisPic2.Size = New System.Drawing.Size(10, 10)
        Me.LouisPic2.TabIndex = 23
        Me.LouisPic2.TabStop = False
        Me.LouisPic2.Visible = False
        '
        'LouisPic1
        '
        Me.LouisPic1.BackColor = System.Drawing.Color.Silver
        Me.LouisPic1.Location = New System.Drawing.Point(16, 96)
        Me.LouisPic1.Name = "LouisPic1"
        Me.LouisPic1.Size = New System.Drawing.Size(10, 10)
        Me.LouisPic1.TabIndex = 22
        Me.LouisPic1.TabStop = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(63, 95)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(81, 16)
        Me.Label25.TabIndex = 21
        Me.Label25.Text = "Louis de Funes"
        '
        'JCVDPic2
        '
        Me.JCVDPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.JCVDPic2.Location = New System.Drawing.Point(16, 13)
        Me.JCVDPic2.Name = "JCVDPic2"
        Me.JCVDPic2.Size = New System.Drawing.Size(10, 10)
        Me.JCVDPic2.TabIndex = 19
        Me.JCVDPic2.TabStop = False
        Me.JCVDPic2.Visible = False
        '
        'StalonePic2
        '
        Me.StalonePic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.StalonePic2.Location = New System.Drawing.Point(16, 33)
        Me.StalonePic2.Name = "StalonePic2"
        Me.StalonePic2.Size = New System.Drawing.Size(10, 10)
        Me.StalonePic2.TabIndex = 19
        Me.StalonePic2.TabStop = False
        Me.StalonePic2.Visible = False
        '
        'AdrianoPic2
        '
        Me.AdrianoPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.AdrianoPic2.Location = New System.Drawing.Point(16, 75)
        Me.AdrianoPic2.Name = "AdrianoPic2"
        Me.AdrianoPic2.Size = New System.Drawing.Size(10, 10)
        Me.AdrianoPic2.TabIndex = 18
        Me.AdrianoPic2.TabStop = False
        Me.AdrianoPic2.Visible = False
        '
        'AdrianoPic1
        '
        Me.AdrianoPic1.BackColor = System.Drawing.Color.Silver
        Me.AdrianoPic1.Location = New System.Drawing.Point(16, 75)
        Me.AdrianoPic1.Name = "AdrianoPic1"
        Me.AdrianoPic1.Size = New System.Drawing.Size(10, 10)
        Me.AdrianoPic1.TabIndex = 17
        Me.AdrianoPic1.TabStop = False
        '
        'ArniPic2
        '
        Me.ArniPic2.BackColor = System.Drawing.SystemColors.Highlight
        Me.ArniPic2.Location = New System.Drawing.Point(16, 54)
        Me.ArniPic2.Name = "ArniPic2"
        Me.ArniPic2.Size = New System.Drawing.Size(10, 10)
        Me.ArniPic2.TabIndex = 16
        Me.ArniPic2.TabStop = False
        '
        'StalonePic1
        '
        Me.StalonePic1.BackColor = System.Drawing.Color.DarkGray
        Me.StalonePic1.Location = New System.Drawing.Point(16, 33)
        Me.StalonePic1.Name = "StalonePic1"
        Me.StalonePic1.Size = New System.Drawing.Size(10, 10)
        Me.StalonePic1.TabIndex = 15
        Me.StalonePic1.TabStop = False
        '
        'JCVDPic1
        '
        Me.JCVDPic1.BackColor = System.Drawing.Color.DarkGray
        Me.JCVDPic1.Location = New System.Drawing.Point(16, 12)
        Me.JCVDPic1.Name = "JCVDPic1"
        Me.JCVDPic1.Size = New System.Drawing.Size(10, 10)
        Me.JCVDPic1.TabIndex = 10
        Me.JCVDPic1.TabStop = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(63, 74)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(99, 16)
        Me.Label26.TabIndex = 14
        Me.Label26.Text = "Adriano Celentano"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(63, 53)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(125, 16)
        Me.Label27.TabIndex = 13
        Me.Label27.Text = "Arnold Schwarzenegger"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(63, 32)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(94, 16)
        Me.Label28.TabIndex = 12
        Me.Label28.Text = "Sylvester Stalone"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(63, 12)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(128, 16)
        Me.Label29.TabIndex = 11
        Me.Label29.Text = "Jean Claude van Damme"
        '
        'JCVDBtn
        '
        Me.JCVDBtn.BackgroundImage = CType(resources.GetObject("JCVDBtn.BackgroundImage"), System.Drawing.Image)
        Me.JCVDBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.JCVDBtn.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.JCVDBtn.Location = New System.Drawing.Point(32, 12)
        Me.JCVDBtn.Name = "JCVDBtn"
        Me.JCVDBtn.Size = New System.Drawing.Size(25, 15)
        Me.JCVDBtn.TabIndex = 7
        Me.JCVDBtn.UseVisualStyleBackColor = True
        '
        'ArniPic1
        '
        Me.ArniPic1.BackColor = System.Drawing.Color.Silver
        Me.ArniPic1.Location = New System.Drawing.Point(16, 54)
        Me.ArniPic1.Name = "ArniPic1"
        Me.ArniPic1.Size = New System.Drawing.Size(10, 10)
        Me.ArniPic1.TabIndex = 19
        Me.ArniPic1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.MovieTown.My.Resources.Resources.Silver_Matt
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(679, 426)
        Me.Controls.Add(Me.ExtraPnl)
        Me.Controls.Add(Me.Panel12)
        Me.Controls.Add(Me.BarBtn2)
        Me.Controls.Add(Me.BarBtn1)
        Me.Controls.Add(Me.Panel10)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.InfoPnl)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.MenuPnlHider)
        Me.Controls.Add(Me.BufferBarOn)
        Me.Controls.Add(Me.BufferBarOff)
        Me.Controls.Add(Me.VolPnl)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button9)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Advanced Online Movie Player Version: 1.0.0.3"
        Me.VLCPnl.ResumeLayout(False)
        CType(Me.AxVLCPlugin21, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.WMPPnl.ResumeLayout(False)
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PlayerPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PlayerPic2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.WesternPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WesternPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FantasyPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FantasyPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ActionPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComedyPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HorrorPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HorrorPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SciFiPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComedyPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ActionPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SciFiPic1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ActionPnl.ResumeLayout(False)
        Me.ActionPnl.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.VolPnl.ResumeLayout(False)
        Me.VolPnl.PerformLayout()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuPnlHider.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.InfoPnl.ResumeLayout(False)
        Me.InfoPnl.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.ExtraPnl.ResumeLayout(False)
        Me.ExtraPnl.PerformLayout()
        CType(Me.KlassikPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KlassikPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LouisPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LouisPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.JCVDPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StalonePic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdrianoPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdrianoPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ArniPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StalonePic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.JCVDPic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ArniPic1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub


    Friend WithEvents VLCPnl As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents ActionList As ComboBox
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents PauseBtn As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents PlayBtn As Button
    Friend WithEvents AxVLCPlugin21 As AxAXVLC.AxVLCPlugin2
    Friend WithEvents Button4 As Button
    Friend WithEvents ActionListPlayBtn As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents WMPPnl As Panel
    Friend WithEvents PlayerBtn1 As Button
    Friend WithEvents PlayerBtn2 As Button
    Friend WithEvents PlayerPic1 As PictureBox
    Friend WithEvents PlayerPic2 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button13 As Button
    Friend WithEvents SciFiBtn As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents ActionPnl As Panel
    Friend WithEvents ComedyList As ComboBox
    Friend WithEvents HorrorList As ComboBox
    Friend WithEvents SciFiList As ComboBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Button18 As Button
    Friend WithEvents InfoOnBtn As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Button14 As Button
    Friend WithEvents PosOnBtn As Button
    Friend WithEvents VolOnBtn As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents SciFiPic1 As PictureBox
    Friend WithEvents ActionPic2 As PictureBox
    Friend WithEvents ComedyPic2 As PictureBox
    Friend WithEvents HorrorPic2 As PictureBox
    Friend WithEvents HorrorPic1 As PictureBox
    Friend WithEvents SciFiPic2 As PictureBox
    Friend WithEvents ComedyPic1 As PictureBox
    Friend WithEvents ActionPic1 As PictureBox
    Friend WithEvents VolPnl As Panel
    Friend WithEvents TrackBar1 As TrackBar
    Friend WithEvents VolOffBtn As Button
    Friend WithEvents TrackBar2 As TrackBar
    Friend WithEvents PosOffBtn As Button
    Friend WithEvents BufferBarOff As ProgressBar
    Friend WithEvents BufferBarOn As ProgressBar
    Friend WithEvents MenuPnlHider As Panel
    Friend WithEvents MenuOn As Button
    Friend WithEvents MenuOff As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents FantasyList As ComboBox
    Friend WithEvents FantasyPic2 As PictureBox
    Friend WithEvents FantasyPic1 As PictureBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Button15 As Button
    Friend WithEvents InfoPnl As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents IMDBlbl As Label
    Friend WithEvents Yearlbl As Label
    Friend WithEvents Genrelbl As Label
    Friend WithEvents Durationlbl As Label
    Friend WithEvents InfoOffBtn As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Milliseklbl As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Seklbl As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Minlbl As Label
    Friend WithEvents TimerResetBtn As Button
    Friend WithEvents TimerStopBtn As Button
    Friend WithEvents Min As Timer
    Friend WithEvents Sek As Timer
    Friend WithEvents Millisek As Timer
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents ComedyListPlayBtn As Button
    Friend WithEvents SciFiListPlayBtn As Button
    Friend WithEvents HorrorListPlayBtn As Button
    Friend WithEvents FantasyListPlayBtn As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents WesternList As ComboBox
    Friend WithEvents WesternPic2 As PictureBox
    Friend WithEvents WesternPic1 As PictureBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Button12 As Button
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Filenamelbl As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents BarBtn1 As Button
    Friend WithEvents BarBtn2 As Button
    Friend WithEvents ExtraPnl As Panel
    Friend WithEvents KlassikPic2 As PictureBox
    Friend WithEvents KlassikPic1 As PictureBox
    Friend WithEvents Label24 As Label
    Friend WithEvents KlassikBtn As Button
    Friend WithEvents LouisPic2 As PictureBox
    Friend WithEvents LouisPic1 As PictureBox
    Friend WithEvents Label25 As Label
    Friend WithEvents LouisBtn As Button
    Friend WithEvents JCVDPic2 As PictureBox
    Friend WithEvents StalonePic2 As PictureBox
    Friend WithEvents AdrianoPic2 As PictureBox
    Friend WithEvents AdrianoPic1 As PictureBox
    Friend WithEvents ArniPic2 As PictureBox
    Friend WithEvents StalonePic1 As PictureBox
    Friend WithEvents JCVDPic1 As PictureBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents AdrianoBtn As Button
    Friend WithEvents ArniBtn As Button
    Friend WithEvents StaloneBtn As Button
    Friend WithEvents JCVDBtn As Button
    Friend WithEvents ArniPic1 As PictureBox
    Friend WithEvents ExtraOnBtn As Button
    Friend WithEvents ExtraOffBtn As Button
    Friend WithEvents JCVDList As ComboBox
    Friend WithEvents AdrianoList As ComboBox
    Friend WithEvents KlassikList As ComboBox
    Friend WithEvents ArniList As ComboBox
    Friend WithEvents StaloneList As ComboBox
    Friend WithEvents LouisList As ComboBox
    Friend WithEvents UpdateBtn As Button
    Friend WithEvents Label31 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label34 As Label
End Class
