﻿Imports System.Resources
Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die einer Assembly zugeordnet sind.

' Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("MovieTown")>
<Assembly: AssemblyDescription("Online Streaming Movie Player")>
<Assembly: AssemblyCompany("EmuZONE Development")>
<Assembly: AssemblyProduct("MovieTown")>
<Assembly: AssemblyCopyright("Copyright ©  2018 EmuZONE Development")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird.
<Assembly: Guid("36ebbb66-ed1c-4f6f-af91-7c603d26b86a")>

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder Standardwerte für die Build- und Revisionsnummern verwenden,
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.3")>
<Assembly: AssemblyFileVersion("1.0.0.3")>
<Assembly: NeutralResourcesLanguage("de")>
