![alt text][logo]

[logo]: Docs/AFG_Screen.png
