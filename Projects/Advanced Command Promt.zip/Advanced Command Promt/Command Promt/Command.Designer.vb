﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Command
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Command))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.OutputTextBox = New System.Windows.Forms.RichTextBox()
        Me.InputTextBox = New System.Windows.Forms.TextBox()
        Me.ExecuteButton = New System.Windows.Forms.Button()
        Me.cmdpnl1 = New System.Windows.Forms.Panel()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.cmdpnlbtn1 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DateiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ÖffnenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LadenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpeichernToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BeendenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BefehleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerwaltungToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProgrammeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BearbeitenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BatchScriptEditorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BatchToExeConvertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExtrasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WeitereSoftwareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreiberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HilfeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformationenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ÜberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.cmdpnl1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.OutputTextBox)
        Me.Panel1.Location = New System.Drawing.Point(0, 23)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(633, 369)
        Me.Panel1.TabIndex = 0
        '
        'OutputTextBox
        '
        Me.OutputTextBox.BackColor = System.Drawing.Color.Black
        Me.OutputTextBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.OutputTextBox.EnableAutoDragDrop = True
        Me.OutputTextBox.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OutputTextBox.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.OutputTextBox.Location = New System.Drawing.Point(24, 28)
        Me.OutputTextBox.Name = "OutputTextBox"
        Me.OutputTextBox.ReadOnly = True
        Me.OutputTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.OutputTextBox.Size = New System.Drawing.Size(584, 320)
        Me.OutputTextBox.TabIndex = 0
        Me.OutputTextBox.Text = ""
        '
        'InputTextBox
        '
        Me.InputTextBox.BackColor = System.Drawing.Color.Black
        Me.InputTextBox.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.InputTextBox.Location = New System.Drawing.Point(12, 3)
        Me.InputTextBox.Multiline = True
        Me.InputTextBox.Name = "InputTextBox"
        Me.InputTextBox.Size = New System.Drawing.Size(407, 30)
        Me.InputTextBox.TabIndex = 1
        '
        'ExecuteButton
        '
        Me.ExecuteButton.BackgroundImage = CType(resources.GetObject("ExecuteButton.BackgroundImage"), System.Drawing.Image)
        Me.ExecuteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ExecuteButton.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExecuteButton.Location = New System.Drawing.Point(463, 395)
        Me.ExecuteButton.Name = "ExecuteButton"
        Me.ExecuteButton.Size = New System.Drawing.Size(80, 36)
        Me.ExecuteButton.TabIndex = 2
        Me.ExecuteButton.Text = "Senden"
        Me.ExecuteButton.UseVisualStyleBackColor = True
        '
        'cmdpnl1
        '
        Me.cmdpnl1.BackColor = System.Drawing.Color.Transparent
        Me.cmdpnl1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.cmdpnl1.Controls.Add(Me.Button61)
        Me.cmdpnl1.Controls.Add(Me.Button22)
        Me.cmdpnl1.Controls.Add(Me.Button23)
        Me.cmdpnl1.Controls.Add(Me.Button24)
        Me.cmdpnl1.Controls.Add(Me.Button25)
        Me.cmdpnl1.Controls.Add(Me.Button17)
        Me.cmdpnl1.Controls.Add(Me.Button18)
        Me.cmdpnl1.Controls.Add(Me.Button19)
        Me.cmdpnl1.Controls.Add(Me.Button20)
        Me.cmdpnl1.Controls.Add(Me.Button13)
        Me.cmdpnl1.Controls.Add(Me.Button14)
        Me.cmdpnl1.Controls.Add(Me.Button15)
        Me.cmdpnl1.Controls.Add(Me.Button16)
        Me.cmdpnl1.Controls.Add(Me.Button9)
        Me.cmdpnl1.Controls.Add(Me.Button10)
        Me.cmdpnl1.Controls.Add(Me.Button11)
        Me.cmdpnl1.Controls.Add(Me.Button12)
        Me.cmdpnl1.Controls.Add(Me.Button5)
        Me.cmdpnl1.Controls.Add(Me.Button6)
        Me.cmdpnl1.Controls.Add(Me.Button7)
        Me.cmdpnl1.Controls.Add(Me.Button8)
        Me.cmdpnl1.Controls.Add(Me.Button3)
        Me.cmdpnl1.Controls.Add(Me.Button2)
        Me.cmdpnl1.Controls.Add(Me.Button1)
        Me.cmdpnl1.Location = New System.Drawing.Point(634, 17)
        Me.cmdpnl1.Name = "cmdpnl1"
        Me.cmdpnl1.Size = New System.Drawing.Size(199, 357)
        Me.cmdpnl1.TabIndex = 3
        '
        'Button61
        '
        Me.Button61.BackgroundImage = CType(resources.GetObject("Button61.BackgroundImage"), System.Drawing.Image)
        Me.Button61.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button61.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button61.ForeColor = System.Drawing.Color.Black
        Me.Button61.Location = New System.Drawing.Point(102, 32)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(90, 30)
        Me.Button61.TabIndex = 28
        Me.Button61.Text = "TIME"
        Me.Button61.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.BackgroundImage = CType(resources.GetObject("Button22.BackgroundImage"), System.Drawing.Image)
        Me.Button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button22.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.ForeColor = System.Drawing.Color.Black
        Me.Button22.Location = New System.Drawing.Point(102, 322)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(90, 30)
        Me.Button22.TabIndex = 27
        Me.Button22.Text = "DEL"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.BackgroundImage = CType(resources.GetObject("Button23.BackgroundImage"), System.Drawing.Image)
        Me.Button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button23.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.ForeColor = System.Drawing.Color.Black
        Me.Button23.Location = New System.Drawing.Point(3, 322)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(90, 30)
        Me.Button23.TabIndex = 26
        Me.Button23.Text = "DATE"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.BackgroundImage = CType(resources.GetObject("Button24.BackgroundImage"), System.Drawing.Image)
        Me.Button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button24.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.ForeColor = System.Drawing.Color.Black
        Me.Button24.Location = New System.Drawing.Point(102, 293)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(90, 30)
        Me.Button24.TabIndex = 25
        Me.Button24.Text = "COPY"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.BackgroundImage = CType(resources.GetObject("Button25.BackgroundImage"), System.Drawing.Image)
        Me.Button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button25.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.ForeColor = System.Drawing.Color.Black
        Me.Button25.Location = New System.Drawing.Point(3, 293)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(90, 30)
        Me.Button25.TabIndex = 24
        Me.Button25.Text = "CONVERT"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.BackgroundImage = CType(resources.GetObject("Button17.BackgroundImage"), System.Drawing.Image)
        Me.Button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button17.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.ForeColor = System.Drawing.Color.Black
        Me.Button17.Location = New System.Drawing.Point(102, 264)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(90, 30)
        Me.Button17.TabIndex = 23
        Me.Button17.Text = "COMPACT"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.BackgroundImage = CType(resources.GetObject("Button18.BackgroundImage"), System.Drawing.Image)
        Me.Button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button18.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.ForeColor = System.Drawing.Color.Black
        Me.Button18.Location = New System.Drawing.Point(3, 264)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(90, 30)
        Me.Button18.TabIndex = 22
        Me.Button18.Text = "COMP"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.BackgroundImage = CType(resources.GetObject("Button19.BackgroundImage"), System.Drawing.Image)
        Me.Button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button19.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.ForeColor = System.Drawing.Color.Black
        Me.Button19.Location = New System.Drawing.Point(102, 235)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(90, 30)
        Me.Button19.TabIndex = 21
        Me.Button19.Text = "COLOR"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.BackgroundImage = CType(resources.GetObject("Button20.BackgroundImage"), System.Drawing.Image)
        Me.Button20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button20.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.ForeColor = System.Drawing.Color.Black
        Me.Button20.Location = New System.Drawing.Point(3, 235)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(90, 30)
        Me.Button20.TabIndex = 20
        Me.Button20.Text = "CMD"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.BackgroundImage = CType(resources.GetObject("Button13.BackgroundImage"), System.Drawing.Image)
        Me.Button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button13.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.Color.Black
        Me.Button13.Location = New System.Drawing.Point(102, 206)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(90, 30)
        Me.Button13.TabIndex = 19
        Me.Button13.Text = "CLS"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.BackgroundImage = CType(resources.GetObject("Button14.BackgroundImage"), System.Drawing.Image)
        Me.Button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button14.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.ForeColor = System.Drawing.Color.Black
        Me.Button14.Location = New System.Drawing.Point(3, 206)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(90, 30)
        Me.Button14.TabIndex = 18
        Me.Button14.Text = "CHKNTFS"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.BackgroundImage = CType(resources.GetObject("Button15.BackgroundImage"), System.Drawing.Image)
        Me.Button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button15.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.ForeColor = System.Drawing.Color.Black
        Me.Button15.Location = New System.Drawing.Point(102, 177)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(90, 30)
        Me.Button15.TabIndex = 17
        Me.Button15.Text = "CHKDSK"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.BackgroundImage = CType(resources.GetObject("Button16.BackgroundImage"), System.Drawing.Image)
        Me.Button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button16.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.ForeColor = System.Drawing.Color.Black
        Me.Button16.Location = New System.Drawing.Point(3, 177)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(90, 30)
        Me.Button16.TabIndex = 16
        Me.Button16.Text = "CHDIR"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.BackgroundImage = CType(resources.GetObject("Button9.BackgroundImage"), System.Drawing.Image)
        Me.Button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button9.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.Black
        Me.Button9.Location = New System.Drawing.Point(102, 148)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(90, 30)
        Me.Button9.TabIndex = 15
        Me.Button9.Text = "CHCP"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackgroundImage = CType(resources.GetObject("Button10.BackgroundImage"), System.Drawing.Image)
        Me.Button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button10.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.Black
        Me.Button10.Location = New System.Drawing.Point(3, 148)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(90, 30)
        Me.Button10.TabIndex = 14
        Me.Button10.Text = "CD"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.BackgroundImage = CType(resources.GetObject("Button11.BackgroundImage"), System.Drawing.Image)
        Me.Button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button11.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.Black
        Me.Button11.Location = New System.Drawing.Point(102, 119)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(90, 30)
        Me.Button11.TabIndex = 13
        Me.Button11.Text = "CALL"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.BackgroundImage = CType(resources.GetObject("Button12.BackgroundImage"), System.Drawing.Image)
        Me.Button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button12.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.ForeColor = System.Drawing.Color.Black
        Me.Button12.Location = New System.Drawing.Point(3, 119)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(90, 30)
        Me.Button12.TabIndex = 12
        Me.Button12.Text = "CALCS"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), System.Drawing.Image)
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button5.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Black
        Me.Button5.Location = New System.Drawing.Point(102, 90)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(90, 30)
        Me.Button5.TabIndex = 11
        Me.Button5.Text = "Boot CFG"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), System.Drawing.Image)
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.Black
        Me.Button6.Location = New System.Drawing.Point(3, 90)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(90, 30)
        Me.Button6.TabIndex = 10
        Me.Button6.Text = "Break"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), System.Drawing.Image)
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button7.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Black
        Me.Button7.Location = New System.Drawing.Point(102, 61)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(90, 30)
        Me.Button7.TabIndex = 9
        Me.Button7.Text = "ATTRIB"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), System.Drawing.Image)
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button8.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.Black
        Me.Button8.Location = New System.Drawing.Point(3, 61)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(90, 30)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "ASSOC"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Black
        Me.Button3.Location = New System.Drawing.Point(3, 32)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(90, 30)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "DIR"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Location = New System.Drawing.Point(102, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(90, 30)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Help"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(3, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 30)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Ping"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.BackgroundImage = Global.Command_Promt.My.Resources.Resources.MenuStrip
        Me.Button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button21.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.Location = New System.Drawing.Point(755, 578)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(81, 28)
        Me.Button21.TabIndex = 23
        Me.Button21.Text = "Exit"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Controls.Add(Me.InputTextBox)
        Me.Panel3.Location = New System.Drawing.Point(10, 395)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(435, 36)
        Me.Panel3.TabIndex = 24
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BackgroundImage = CType(resources.GetObject("Panel4.BackgroundImage"), System.Drawing.Image)
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.Button27)
        Me.Panel4.Controls.Add(Me.Button37)
        Me.Panel4.Controls.Add(Me.Button29)
        Me.Panel4.Controls.Add(Me.Button36)
        Me.Panel4.Controls.Add(Me.Button31)
        Me.Panel4.Controls.Add(Me.Button35)
        Me.Panel4.Controls.Add(Me.Button34)
        Me.Panel4.Controls.Add(Me.Button32)
        Me.Panel4.Controls.Add(Me.Button26)
        Me.Panel4.Controls.Add(Me.Button33)
        Me.Panel4.Controls.Add(Me.Button30)
        Me.Panel4.Controls.Add(Me.Button28)
        Me.Panel4.Location = New System.Drawing.Point(24, 477)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(353, 120)
        Me.Panel4.TabIndex = 25
        '
        'Button27
        '
        Me.Button27.BackgroundImage = CType(resources.GetObject("Button27.BackgroundImage"), System.Drawing.Image)
        Me.Button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button27.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.ForeColor = System.Drawing.Color.Black
        Me.Button27.Location = New System.Drawing.Point(255, 72)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(82, 35)
        Me.Button27.TabIndex = 26
        Me.Button27.Text = "Hintergrund"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.BackgroundImage = CType(resources.GetObject("Button37.BackgroundImage"), System.Drawing.Image)
        Me.Button37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button37.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button37.ForeColor = System.Drawing.Color.Black
        Me.Button37.Location = New System.Drawing.Point(174, 5)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(82, 35)
        Me.Button37.TabIndex = 16
        Me.Button37.Text = "Font"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.BackgroundImage = CType(resources.GetObject("Button29.BackgroundImage"), System.Drawing.Image)
        Me.Button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button29.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.ForeColor = System.Drawing.Color.Black
        Me.Button29.Location = New System.Drawing.Point(255, 38)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(82, 35)
        Me.Button29.TabIndex = 24
        Me.Button29.Text = "Schrift"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.BackgroundImage = CType(resources.GetObject("Button36.BackgroundImage"), System.Drawing.Image)
        Me.Button36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button36.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.ForeColor = System.Drawing.Color.Black
        Me.Button36.Location = New System.Drawing.Point(174, 72)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(82, 35)
        Me.Button36.TabIndex = 17
        Me.Button36.Text = "Format"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.BackgroundImage = CType(resources.GetObject("Button31.BackgroundImage"), System.Drawing.Image)
        Me.Button31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button31.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.ForeColor = System.Drawing.Color.Black
        Me.Button31.Location = New System.Drawing.Point(255, 5)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(82, 35)
        Me.Button31.TabIndex = 22
        Me.Button31.Text = "Farbwahl"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.BackgroundImage = CType(resources.GetObject("Button35.BackgroundImage"), System.Drawing.Image)
        Me.Button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button35.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button35.ForeColor = System.Drawing.Color.Black
        Me.Button35.Location = New System.Drawing.Point(93, 72)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(82, 35)
        Me.Button35.TabIndex = 18
        Me.Button35.Text = "Kopieren"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.BackgroundImage = CType(resources.GetObject("Button34.BackgroundImage"), System.Drawing.Image)
        Me.Button34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button34.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.ForeColor = System.Drawing.Color.Black
        Me.Button34.Location = New System.Drawing.Point(93, 5)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(82, 35)
        Me.Button34.TabIndex = 19
        Me.Button34.Text = "IP Config"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.BackgroundImage = CType(resources.GetObject("Button32.BackgroundImage"), System.Drawing.Image)
        Me.Button32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button32.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button32.ForeColor = System.Drawing.Color.Black
        Me.Button32.Location = New System.Drawing.Point(12, 38)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(82, 35)
        Me.Button32.TabIndex = 21
        Me.Button32.Text = "System"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.BackgroundImage = CType(resources.GetObject("Button26.BackgroundImage"), System.Drawing.Image)
        Me.Button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button26.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.ForeColor = System.Drawing.Color.Black
        Me.Button26.Location = New System.Drawing.Point(174, 38)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(82, 35)
        Me.Button26.TabIndex = 27
        Me.Button26.Text = "Zoom"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.BackgroundImage = CType(resources.GetObject("Button33.BackgroundImage"), System.Drawing.Image)
        Me.Button33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button33.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.ForeColor = System.Drawing.Color.Black
        Me.Button33.Location = New System.Drawing.Point(12, 5)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(82, 35)
        Me.Button33.TabIndex = 20
        Me.Button33.Text = "Schriftfarbe"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.BackgroundImage = CType(resources.GetObject("Button30.BackgroundImage"), System.Drawing.Image)
        Me.Button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button30.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.ForeColor = System.Drawing.Color.Black
        Me.Button30.Location = New System.Drawing.Point(12, 72)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(82, 35)
        Me.Button30.TabIndex = 23
        Me.Button30.Text = "ZDFinfo REC"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.BackgroundImage = CType(resources.GetObject("Button28.BackgroundImage"), System.Drawing.Image)
        Me.Button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button28.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.ForeColor = System.Drawing.Color.Black
        Me.Button28.Location = New System.Drawing.Point(93, 38)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(82, 35)
        Me.Button28.TabIndex = 25
        Me.Button28.Text = "Batch"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(453, 448)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(155, 149)
        Me.PictureBox1.TabIndex = 26
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(574, 439)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(225, 80)
        Me.PictureBox2.TabIndex = 27
        Me.PictureBox2.TabStop = False
        '
        'cmdpnlbtn1
        '
        Me.cmdpnlbtn1.BackgroundImage = CType(resources.GetObject("cmdpnlbtn1.BackgroundImage"), System.Drawing.Image)
        Me.cmdpnlbtn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.cmdpnlbtn1.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdpnlbtn1.Location = New System.Drawing.Point(768, 386)
        Me.cmdpnlbtn1.Name = "cmdpnlbtn1"
        Me.cmdpnlbtn1.Size = New System.Drawing.Size(70, 30)
        Me.cmdpnlbtn1.TabIndex = 28
        Me.cmdpnlbtn1.Text = "Wechseln"
        Me.cmdpnlbtn1.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.Button4)
        Me.Panel5.Controls.Add(Me.Button38)
        Me.Panel5.Controls.Add(Me.Button39)
        Me.Panel5.Controls.Add(Me.Button40)
        Me.Panel5.Controls.Add(Me.Button41)
        Me.Panel5.Controls.Add(Me.Button42)
        Me.Panel5.Controls.Add(Me.Button43)
        Me.Panel5.Controls.Add(Me.Button44)
        Me.Panel5.Controls.Add(Me.Button45)
        Me.Panel5.Controls.Add(Me.Button46)
        Me.Panel5.Controls.Add(Me.Button47)
        Me.Panel5.Controls.Add(Me.Button48)
        Me.Panel5.Controls.Add(Me.Button49)
        Me.Panel5.Controls.Add(Me.Button50)
        Me.Panel5.Controls.Add(Me.Button51)
        Me.Panel5.Controls.Add(Me.Button52)
        Me.Panel5.Controls.Add(Me.Button53)
        Me.Panel5.Controls.Add(Me.Button54)
        Me.Panel5.Controls.Add(Me.Button55)
        Me.Panel5.Controls.Add(Me.Button56)
        Me.Panel5.Controls.Add(Me.Button57)
        Me.Panel5.Controls.Add(Me.Button58)
        Me.Panel5.Controls.Add(Me.Button59)
        Me.Panel5.Controls.Add(Me.Button60)
        Me.Panel5.Location = New System.Drawing.Point(634, 17)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(199, 357)
        Me.Panel5.TabIndex = 29
        '
        'Button4
        '
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), System.Drawing.Image)
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Black
        Me.Button4.Location = New System.Drawing.Point(102, 32)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(90, 30)
        Me.Button4.TabIndex = 28
        Me.Button4.Text = "FORMAT"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.BackgroundImage = CType(resources.GetObject("Button38.BackgroundImage"), System.Drawing.Image)
        Me.Button38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button38.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.ForeColor = System.Drawing.Color.Black
        Me.Button38.Location = New System.Drawing.Point(102, 322)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(90, 30)
        Me.Button38.TabIndex = 27
        Me.Button38.Text = "MODE"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.BackgroundImage = CType(resources.GetObject("Button39.BackgroundImage"), System.Drawing.Image)
        Me.Button39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button39.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button39.ForeColor = System.Drawing.Color.Black
        Me.Button39.Location = New System.Drawing.Point(3, 322)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(90, 30)
        Me.Button39.TabIndex = 26
        Me.Button39.Text = "FIND"
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.BackgroundImage = CType(resources.GetObject("Button40.BackgroundImage"), System.Drawing.Image)
        Me.Button40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button40.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.ForeColor = System.Drawing.Color.Black
        Me.Button40.Location = New System.Drawing.Point(102, 293)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(90, 30)
        Me.Button40.TabIndex = 25
        Me.Button40.Text = "MKLINK"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.BackgroundImage = CType(resources.GetObject("Button41.BackgroundImage"), System.Drawing.Image)
        Me.Button41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button41.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.ForeColor = System.Drawing.Color.Black
        Me.Button41.Location = New System.Drawing.Point(3, 293)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(90, 30)
        Me.Button41.TabIndex = 24
        Me.Button41.Text = "FC"
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button42
        '
        Me.Button42.BackgroundImage = CType(resources.GetObject("Button42.BackgroundImage"), System.Drawing.Image)
        Me.Button42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button42.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.ForeColor = System.Drawing.Color.Black
        Me.Button42.Location = New System.Drawing.Point(102, 264)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(90, 30)
        Me.Button42.TabIndex = 23
        Me.Button42.Text = "MKDIR"
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.BackgroundImage = CType(resources.GetObject("Button43.BackgroundImage"), System.Drawing.Image)
        Me.Button43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button43.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button43.ForeColor = System.Drawing.Color.Black
        Me.Button43.Location = New System.Drawing.Point(3, 264)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(90, 30)
        Me.Button43.TabIndex = 22
        Me.Button43.Text = "EXIT"
        Me.Button43.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.BackgroundImage = CType(resources.GetObject("Button44.BackgroundImage"), System.Drawing.Image)
        Me.Button44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button44.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.ForeColor = System.Drawing.Color.Black
        Me.Button44.Location = New System.Drawing.Point(102, 235)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(90, 30)
        Me.Button44.TabIndex = 21
        Me.Button44.Text = "LABEL "
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button45
        '
        Me.Button45.BackgroundImage = CType(resources.GetObject("Button45.BackgroundImage"), System.Drawing.Image)
        Me.Button45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button45.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button45.ForeColor = System.Drawing.Color.Black
        Me.Button45.Location = New System.Drawing.Point(3, 235)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(90, 30)
        Me.Button45.TabIndex = 20
        Me.Button45.Text = "ERASE "
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button46
        '
        Me.Button46.BackgroundImage = CType(resources.GetObject("Button46.BackgroundImage"), System.Drawing.Image)
        Me.Button46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button46.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button46.ForeColor = System.Drawing.Color.Black
        Me.Button46.Location = New System.Drawing.Point(102, 206)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(90, 30)
        Me.Button46.TabIndex = 19
        Me.Button46.Text = "ICACLS"
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Button47
        '
        Me.Button47.BackgroundImage = CType(resources.GetObject("Button47.BackgroundImage"), System.Drawing.Image)
        Me.Button47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button47.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button47.ForeColor = System.Drawing.Color.Black
        Me.Button47.Location = New System.Drawing.Point(3, 206)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(90, 30)
        Me.Button47.TabIndex = 18
        Me.Button47.Text = "ENDLOCAL"
        Me.Button47.UseVisualStyleBackColor = True
        '
        'Button48
        '
        Me.Button48.BackgroundImage = CType(resources.GetObject("Button48.BackgroundImage"), System.Drawing.Image)
        Me.Button48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button48.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button48.ForeColor = System.Drawing.Color.Black
        Me.Button48.Location = New System.Drawing.Point(102, 177)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(90, 30)
        Me.Button48.TabIndex = 17
        Me.Button48.Text = "GRAFTABL"
        Me.Button48.UseVisualStyleBackColor = True
        '
        'Button49
        '
        Me.Button49.BackgroundImage = CType(resources.GetObject("Button49.BackgroundImage"), System.Drawing.Image)
        Me.Button49.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button49.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button49.ForeColor = System.Drawing.Color.Black
        Me.Button49.Location = New System.Drawing.Point(3, 177)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(90, 30)
        Me.Button49.TabIndex = 16
        Me.Button49.Text = "ECHO"
        Me.Button49.UseVisualStyleBackColor = True
        '
        'Button50
        '
        Me.Button50.BackgroundImage = CType(resources.GetObject("Button50.BackgroundImage"), System.Drawing.Image)
        Me.Button50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button50.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button50.ForeColor = System.Drawing.Color.Black
        Me.Button50.Location = New System.Drawing.Point(102, 148)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(90, 30)
        Me.Button50.TabIndex = 15
        Me.Button50.Text = "GPRESULT"
        Me.Button50.UseVisualStyleBackColor = True
        '
        'Button51
        '
        Me.Button51.BackgroundImage = CType(resources.GetObject("Button51.BackgroundImage"), System.Drawing.Image)
        Me.Button51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button51.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button51.ForeColor = System.Drawing.Color.Black
        Me.Button51.Location = New System.Drawing.Point(3, 148)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(90, 30)
        Me.Button51.TabIndex = 14
        Me.Button51.Text = "DRIVERQUERY"
        Me.Button51.UseVisualStyleBackColor = True
        '
        'Button52
        '
        Me.Button52.BackgroundImage = CType(resources.GetObject("Button52.BackgroundImage"), System.Drawing.Image)
        Me.Button52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button52.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button52.ForeColor = System.Drawing.Color.Black
        Me.Button52.Location = New System.Drawing.Point(102, 119)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(90, 30)
        Me.Button52.TabIndex = 13
        Me.Button52.Text = "GOTO"
        Me.Button52.UseVisualStyleBackColor = True
        '
        'Button53
        '
        Me.Button53.BackgroundImage = CType(resources.GetObject("Button53.BackgroundImage"), System.Drawing.Image)
        Me.Button53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button53.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button53.ForeColor = System.Drawing.Color.Black
        Me.Button53.Location = New System.Drawing.Point(3, 119)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(90, 30)
        Me.Button53.TabIndex = 12
        Me.Button53.Text = "DOSKEY"
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Button54
        '
        Me.Button54.BackgroundImage = CType(resources.GetObject("Button54.BackgroundImage"), System.Drawing.Image)
        Me.Button54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button54.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button54.ForeColor = System.Drawing.Color.Black
        Me.Button54.Location = New System.Drawing.Point(102, 90)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(90, 30)
        Me.Button54.TabIndex = 11
        Me.Button54.Text = "FTYPE"
        Me.Button54.UseVisualStyleBackColor = True
        '
        'Button55
        '
        Me.Button55.BackgroundImage = CType(resources.GetObject("Button55.BackgroundImage"), System.Drawing.Image)
        Me.Button55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button55.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button55.ForeColor = System.Drawing.Color.Black
        Me.Button55.Location = New System.Drawing.Point(3, 90)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(90, 30)
        Me.Button55.TabIndex = 10
        Me.Button55.Text = "DISKPART"
        Me.Button55.UseVisualStyleBackColor = True
        '
        'Button56
        '
        Me.Button56.BackgroundImage = CType(resources.GetObject("Button56.BackgroundImage"), System.Drawing.Image)
        Me.Button56.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button56.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button56.ForeColor = System.Drawing.Color.Black
        Me.Button56.Location = New System.Drawing.Point(102, 61)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(90, 30)
        Me.Button56.TabIndex = 9
        Me.Button56.Text = "FSUTIL"
        Me.Button56.UseVisualStyleBackColor = True
        '
        'Button57
        '
        Me.Button57.BackgroundImage = CType(resources.GetObject("Button57.BackgroundImage"), System.Drawing.Image)
        Me.Button57.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button57.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button57.ForeColor = System.Drawing.Color.Black
        Me.Button57.Location = New System.Drawing.Point(3, 61)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(90, 30)
        Me.Button57.TabIndex = 8
        Me.Button57.Text = "DISKCOPY "
        Me.Button57.UseVisualStyleBackColor = True
        '
        'Button58
        '
        Me.Button58.BackgroundImage = CType(resources.GetObject("Button58.BackgroundImage"), System.Drawing.Image)
        Me.Button58.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button58.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button58.ForeColor = System.Drawing.Color.Black
        Me.Button58.Location = New System.Drawing.Point(3, 32)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(90, 30)
        Me.Button58.TabIndex = 6
        Me.Button58.Text = "DISKCOMP"
        Me.Button58.UseVisualStyleBackColor = True
        '
        'Button59
        '
        Me.Button59.BackgroundImage = CType(resources.GetObject("Button59.BackgroundImage"), System.Drawing.Image)
        Me.Button59.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button59.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button59.ForeColor = System.Drawing.Color.Black
        Me.Button59.Location = New System.Drawing.Point(102, 3)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(90, 30)
        Me.Button59.TabIndex = 5
        Me.Button59.Text = "FINDSTR"
        Me.Button59.UseVisualStyleBackColor = True
        '
        'Button60
        '
        Me.Button60.BackgroundImage = CType(resources.GetObject("Button60.BackgroundImage"), System.Drawing.Image)
        Me.Button60.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button60.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button60.ForeColor = System.Drawing.Color.Black
        Me.Button60.Location = New System.Drawing.Point(3, 3)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(90, 30)
        Me.Button60.TabIndex = 4
        Me.Button60.Text = "Directory"
        Me.Button60.UseVisualStyleBackColor = True
        '
        'Button62
        '
        Me.Button62.BackgroundImage = CType(resources.GetObject("Button62.BackgroundImage"), System.Drawing.Image)
        Me.Button62.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button62.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button62.Location = New System.Drawing.Point(768, 386)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(70, 30)
        Me.Button62.TabIndex = 30
        Me.Button62.Text = "Wechseln"
        Me.Button62.UseVisualStyleBackColor = True
        Me.Button62.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DateiToolStripMenuItem, Me.SystemToolStripMenuItem, Me.BearbeitenToolStripMenuItem, Me.ExtrasToolStripMenuItem, Me.HilfeToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(848, 24)
        Me.MenuStrip1.TabIndex = 31
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DateiToolStripMenuItem
        '
        Me.DateiToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DateiToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ÖffnenToolStripMenuItem, Me.LadenToolStripMenuItem, Me.SpeichernToolStripMenuItem, Me.BeendenToolStripMenuItem})
        Me.DateiToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.DateiToolStripMenuItem.Name = "DateiToolStripMenuItem"
        Me.DateiToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.DateiToolStripMenuItem.Text = "Datei"
        '
        'ÖffnenToolStripMenuItem
        '
        Me.ÖffnenToolStripMenuItem.BackgroundImage = CType(resources.GetObject("ÖffnenToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.ÖffnenToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ÖffnenToolStripMenuItem.Name = "ÖffnenToolStripMenuItem"
        Me.ÖffnenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ÖffnenToolStripMenuItem.Text = "&Öffnen"
        '
        'LadenToolStripMenuItem
        '
        Me.LadenToolStripMenuItem.BackgroundImage = CType(resources.GetObject("LadenToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.LadenToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.LadenToolStripMenuItem.Name = "LadenToolStripMenuItem"
        Me.LadenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LadenToolStripMenuItem.Text = "&Laden"
        '
        'SpeichernToolStripMenuItem
        '
        Me.SpeichernToolStripMenuItem.BackgroundImage = CType(resources.GetObject("SpeichernToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.SpeichernToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SpeichernToolStripMenuItem.Name = "SpeichernToolStripMenuItem"
        Me.SpeichernToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SpeichernToolStripMenuItem.Text = "&Speichern"
        '
        'BeendenToolStripMenuItem
        '
        Me.BeendenToolStripMenuItem.BackgroundImage = CType(resources.GetObject("BeendenToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.BeendenToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BeendenToolStripMenuItem.Name = "BeendenToolStripMenuItem"
        Me.BeendenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BeendenToolStripMenuItem.Text = "&Beenden"
        '
        'SystemToolStripMenuItem
        '
        Me.SystemToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SystemToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BefehleToolStripMenuItem, Me.VerwaltungToolStripMenuItem, Me.ProgrammeToolStripMenuItem})
        Me.SystemToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.SystemToolStripMenuItem.Name = "SystemToolStripMenuItem"
        Me.SystemToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.SystemToolStripMenuItem.Text = "System"
        '
        'BefehleToolStripMenuItem
        '
        Me.BefehleToolStripMenuItem.BackgroundImage = CType(resources.GetObject("BefehleToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.BefehleToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BefehleToolStripMenuItem.Name = "BefehleToolStripMenuItem"
        Me.BefehleToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BefehleToolStripMenuItem.Text = "&Befehle"
        '
        'VerwaltungToolStripMenuItem
        '
        Me.VerwaltungToolStripMenuItem.BackgroundImage = CType(resources.GetObject("VerwaltungToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.VerwaltungToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.VerwaltungToolStripMenuItem.Name = "VerwaltungToolStripMenuItem"
        Me.VerwaltungToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.VerwaltungToolStripMenuItem.Text = "&Verwaltung"
        '
        'ProgrammeToolStripMenuItem
        '
        Me.ProgrammeToolStripMenuItem.BackgroundImage = CType(resources.GetObject("ProgrammeToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.ProgrammeToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ProgrammeToolStripMenuItem.Name = "ProgrammeToolStripMenuItem"
        Me.ProgrammeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ProgrammeToolStripMenuItem.Text = "&Programme"
        '
        'BearbeitenToolStripMenuItem
        '
        Me.BearbeitenToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BatchScriptEditorToolStripMenuItem, Me.BatchToExeConvertToolStripMenuItem})
        Me.BearbeitenToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.BearbeitenToolStripMenuItem.Name = "BearbeitenToolStripMenuItem"
        Me.BearbeitenToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.BearbeitenToolStripMenuItem.Text = "Bearbeiten"
        '
        'BatchScriptEditorToolStripMenuItem
        '
        Me.BatchScriptEditorToolStripMenuItem.BackgroundImage = CType(resources.GetObject("BatchScriptEditorToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.BatchScriptEditorToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BatchScriptEditorToolStripMenuItem.Name = "BatchScriptEditorToolStripMenuItem"
        Me.BatchScriptEditorToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.BatchScriptEditorToolStripMenuItem.Text = "&Batch Script Editor"
        '
        'BatchToExeConvertToolStripMenuItem
        '
        Me.BatchToExeConvertToolStripMenuItem.BackgroundImage = CType(resources.GetObject("BatchToExeConvertToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.BatchToExeConvertToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BatchToExeConvertToolStripMenuItem.Name = "BatchToExeConvertToolStripMenuItem"
        Me.BatchToExeConvertToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.BatchToExeConvertToolStripMenuItem.Text = "Batch to Exe Convert"
        '
        'ExtrasToolStripMenuItem
        '
        Me.ExtrasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WeitereSoftwareToolStripMenuItem, Me.TreiberToolStripMenuItem})
        Me.ExtrasToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.ExtrasToolStripMenuItem.Name = "ExtrasToolStripMenuItem"
        Me.ExtrasToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.ExtrasToolStripMenuItem.Text = "Extras"
        '
        'WeitereSoftwareToolStripMenuItem
        '
        Me.WeitereSoftwareToolStripMenuItem.BackgroundImage = Global.Command_Promt.My.Resources.Resources.MenuStrip
        Me.WeitereSoftwareToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.WeitereSoftwareToolStripMenuItem.Name = "WeitereSoftwareToolStripMenuItem"
        Me.WeitereSoftwareToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.WeitereSoftwareToolStripMenuItem.Text = "Weitere Software"
        '
        'TreiberToolStripMenuItem
        '
        Me.TreiberToolStripMenuItem.BackgroundImage = Global.Command_Promt.My.Resources.Resources.MenuStrip
        Me.TreiberToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TreiberToolStripMenuItem.Name = "TreiberToolStripMenuItem"
        Me.TreiberToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.TreiberToolStripMenuItem.Text = "Treiber"
        '
        'HilfeToolStripMenuItem
        '
        Me.HilfeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformationenToolStripMenuItem, Me.ÜberToolStripMenuItem})
        Me.HilfeToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.HilfeToolStripMenuItem.Name = "HilfeToolStripMenuItem"
        Me.HilfeToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HilfeToolStripMenuItem.Text = "Hilfe"
        '
        'InformationenToolStripMenuItem
        '
        Me.InformationenToolStripMenuItem.Name = "InformationenToolStripMenuItem"
        Me.InformationenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.InformationenToolStripMenuItem.Text = "Informationen"
        '
        'ÜberToolStripMenuItem
        '
        Me.ÜberToolStripMenuItem.Name = "ÜberToolStripMenuItem"
        Me.ÜberToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ÜberToolStripMenuItem.Text = "&Über..."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(614, 531)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(173, 21)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "Professional CMD Office"
        '
        'Command
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Command_Promt.My.Resources.Resources.Silver_Matt
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(848, 618)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button62)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.cmdpnlbtn1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.cmdpnl1)
        Me.Controls.Add(Me.ExecuteButton)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Command"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Advanced Command Center 2018"
        Me.Panel1.ResumeLayout(False)
        Me.cmdpnl1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents OutputTextBox As RichTextBox
    Friend WithEvents InputTextBox As TextBox
    Friend WithEvents ExecuteButton As Button
    Friend WithEvents cmdpnl1 As Panel
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button61 As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Button27 As Button
    Friend WithEvents Button37 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button36 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button39 As Button
    Friend WithEvents Button40 As Button
    Friend WithEvents Button41 As Button
    Friend WithEvents Button42 As Button
    Friend WithEvents Button43 As Button
    Friend WithEvents Button44 As Button
    Friend WithEvents Button45 As Button
    Friend WithEvents Button46 As Button
    Friend WithEvents Button47 As Button
    Friend WithEvents Button48 As Button
    Friend WithEvents Button49 As Button
    Friend WithEvents Button50 As Button
    Friend WithEvents Button51 As Button
    Friend WithEvents Button52 As Button
    Friend WithEvents Button53 As Button
    Friend WithEvents Button54 As Button
    Friend WithEvents Button55 As Button
    Friend WithEvents Button56 As Button
    Friend WithEvents Button57 As Button
    Friend WithEvents Button58 As Button
    Friend WithEvents Button59 As Button
    Friend WithEvents Button60 As Button
    Friend WithEvents cmdpnlbtn1 As Button
    Friend WithEvents Button62 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DateiToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ÖffnenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LadenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SpeichernToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BeendenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SystemToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BefehleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerwaltungToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProgrammeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BearbeitenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BatchScriptEditorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BatchToExeConvertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExtrasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WeitereSoftwareToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TreiberToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HilfeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InformationenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ÜberToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
End Class
